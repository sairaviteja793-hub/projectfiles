-- Add staff role + extend policies so staff can do everything admin can EXCEPT
-- manage roles, payment_settings, offline_sales, or view aggregated revenue analytics.

ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'staff';

CREATE OR REPLACE FUNCTION public.is_staff_or_admin(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS(
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role IN ('admin','staff')
  )
$$;

REVOKE EXECUTE ON FUNCTION public.is_staff_or_admin(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_staff_or_admin(uuid) TO authenticated, service_role;

DROP POLICY IF EXISTS "View own profile or admin" ON public.profiles;
CREATE POLICY "View own profile or staff" ON public.profiles
  FOR SELECT USING (auth.uid() = id OR public.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "Users view own bookings or admin" ON public.bookings;
CREATE POLICY "Users view own bookings or staff" ON public.bookings
  FOR SELECT USING (auth.uid() = user_id OR public.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins update bookings" ON public.bookings;
CREATE POLICY "Staff update bookings" ON public.bookings
  FOR UPDATE USING (public.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage services" ON public.services;
CREATE POLICY "Staff manage services" ON public.services
  FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage announcements" ON public.announcements;
CREATE POLICY "Staff manage announcements" ON public.announcements
  FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage notifications" ON public.user_notifications;
CREATE POLICY "Staff manage notifications" ON public.user_notifications
  FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins insert profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins update profiles" ON public.profiles;
CREATE POLICY "Staff insert profiles" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = id OR public.is_staff_or_admin(auth.uid()));
CREATE POLICY "Staff update any profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id OR public.is_staff_or_admin(auth.uid()));
