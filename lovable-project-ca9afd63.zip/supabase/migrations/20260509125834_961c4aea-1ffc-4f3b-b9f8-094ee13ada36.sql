
-- search_path on touch_updated_at
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- Tighten bookings insert policy
DROP POLICY IF EXISTS "Anyone create bookings" ON public.bookings;
CREATE POLICY "Create own or guest bookings" ON public.bookings
  FOR INSERT WITH CHECK (user_id IS NULL OR user_id = auth.uid());

-- Lock down trigger functions (only invoked by triggers, never directly)
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.touch_updated_at() FROM PUBLIC, anon, authenticated;
