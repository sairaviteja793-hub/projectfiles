import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, Shield, Sparkles, Clock, Award, Gem, Watch, Wrench, Truck, Star, Lock, BadgeCheck } from "lucide-react";
import heroImg from "@/assets/hero-luxury.jpg";
import craftsmanImg from "@/assets/craftsman.jpg";
import jewelryImg from "@/assets/jewelry.jpg";
import watchImg from "@/assets/watch-movement.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Quality Jewelry Repair — Premium Mail-In Jewelry & Watch Atelier" },
      { name: "description", content: "Master craftsmanship for jewelry & watch repair. Mail-in service with insured shipping, transparent pricing, and 200,000+ happy customers." },
    ],
  }),
  component: HomePage,
});

const fadeUp: any = {
  hidden: { opacity: 0, y: 30 },
  visible: (i = 0) => ({ opacity: 1, y: 0, transition: { duration: 0.8, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] } }),
};

function HomePage() {
  return (
    <div className="overflow-x-clip">
      {/* HERO */}
      <section className="relative min-h-[92vh] flex items-center">
        <div className="absolute inset-0 -z-10">
          <img
            src={heroImg}
            alt="Luxury gold pocket watch and diamond ring"
            width={1536}
            height={1280}
            className="h-full w-full object-cover opacity-50"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/85 to-background/30" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-transparent to-background" />
        </div>

        <div className="mx-auto max-w-7xl px-6 py-24 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <motion.div
              initial="hidden" animate="visible" variants={fadeUp}
              className="inline-flex items-center gap-2 rounded-full border border-gold/30 bg-card/40 px-4 py-1.5 text-xs uppercase tracking-[0.25em] text-gold"
            >
              <Sparkles className="h-3.5 w-3.5" /> Trusted by 200,000+ Customers
            </motion.div>

            <motion.h1
              initial="hidden" animate="visible" variants={fadeUp} custom={1}
              className="mt-6 font-display text-5xl md:text-7xl leading-[1.05] text-foreground"
            >
              The Art of <span className="gradient-gold-text italic">Restoration</span>
              <br />Delivered to Your Door.
            </motion.h1>

            <motion.p
              initial="hidden" animate="visible" variants={fadeUp} custom={2}
              className="mt-6 max-w-xl text-lg text-muted-foreground leading-relaxed"
            >
              A premium mail-in atelier for jewelry & watch repair. Master craftsmen,
              fully insured shipping, transparent pricing — and a finish that
              feels like the day you first wore it.
            </motion.p>

            <motion.div
              initial="hidden" animate="visible" variants={fadeUp} custom={3}
              className="mt-10 flex flex-wrap items-center gap-4"
            >
              <Link to="/repair" className="group inline-flex items-center gap-2 rounded-full bg-gold px-8 py-4 text-sm font-medium uppercase tracking-[0.2em] text-primary-foreground shadow-gold transition-all duration-500 hover:scale-105 hover:shadow-luxe"
              >
                Start Your Repair
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                to="/how-it-works"
                className="inline-flex items-center gap-2 rounded-full border border-border px-8 py-4 text-sm uppercase tracking-[0.2em] text-foreground/80 hover:border-gold hover:text-gold transition-colors"
              >
                How It Works
              </Link>
            </motion.div>

            <motion.div
              initial="hidden" animate="visible" variants={fadeUp} custom={4}
              className="mt-12 grid grid-cols-3 gap-6 max-w-md"
            >
              {[
                { v: "200K+", l: "Customers" },
                { v: "4.9★", l: "Rating" },
                { v: "100%", l: "Insured" },
              ].map((s) => (
                <div key={s.l}>
                  <div className="font-display text-3xl text-gold">{s.v}</div>
                  <div className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{s.l}</div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Floating accent card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.4 }}
            className="hidden lg:block relative"
          >
            <div className="relative animate-float">
              <div className="absolute -inset-8 rounded-full bg-gold/20 blur-3xl" />
              <div className="relative glass rounded-3xl p-8 shadow-luxe">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gold/15 border border-gold/30">
                    <Lock className="h-5 w-5 text-gold" />
                  </div>
                  <div>
                    <div className="text-sm uppercase tracking-widest text-gold">Secure Checkout</div>
                    <div className="text-xs text-muted-foreground">256-bit SSL · PCI compliant</div>
                  </div>
                </div>
                <div className="gold-divider my-6" />
                <ul className="space-y-3 text-sm">
                  {["Insured 2-way shipping", "Transparent flat pricing", "Master craftsmen", "30-day satisfaction"].map((t) => (
                    <li key={t} className="flex items-center gap-3 text-foreground/80">
                      <BadgeCheck className="h-4 w-4 text-gold" /> {t}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>
        </div>

        {/* scroll cue */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-xs uppercase tracking-[0.4em] text-muted-foreground animate-pulse">
          Scroll
        </div>
      </section>

      {/* MARQUEE TRUST */}
      <section className="relative overflow-hidden border-y border-border/50 bg-card/30 py-6">
        <div className="flex animate-marquee whitespace-nowrap">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="flex shrink-0 items-center gap-16 pr-16 text-sm uppercase tracking-[0.3em] text-muted-foreground">
              <span className="flex items-center gap-3"><Shield className="h-4 w-4 text-gold" /> Fully Insured</span>
              <span className="flex items-center gap-3"><Award className="h-4 w-4 text-gold" /> Master Jewelers</span>
              <span className="flex items-center gap-3"><Truck className="h-4 w-4 text-gold" /> Free 2-Way Shipping</span>
              <span className="flex items-center gap-3"><Clock className="h-4 w-4 text-gold" /> 7–14 Day Turnaround</span>
              <span className="flex items-center gap-3"><Star className="h-4 w-4 text-gold" /> 4.9/5 Rated Service</span>
              <span className="flex items-center gap-3"><Gem className="h-4 w-4 text-gold" /> Lifetime Workmanship</span>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES */}
      <section className="mx-auto max-w-7xl px-6 py-28">
        <motion.div
          initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.3 }} variants={fadeUp}
          className="max-w-2xl"
        >
          <p className="text-xs uppercase tracking-[0.3em] text-gold">What we restore</p>
          <h2 className="mt-4 font-display text-5xl md:text-6xl">A craft refined over decades.</h2>
          <p className="mt-6 text-muted-foreground">
            From heirloom rings to mechanical watches, every piece passes through expert
            hands and is returned looking — and feeling — exquisite.
          </p>
        </motion.div>

        <div className="mt-16 grid md:grid-cols-3 gap-6">
          {[
            { img: jewelryImg, icon: Gem, title: "Fine Jewelry", desc: "Ring resizing, prong retipping, stone setting, soldering, polishing & rhodium plating." },
            { img: watchImg, icon: Watch, title: "Luxury Watches", desc: "Battery replacement, full movement service, crystal & crown repair, restoration." },
            { img: craftsmanImg, icon: Wrench, title: "Restoration", desc: "Antique restoration, chain repair, clasp replacement, custom design & engraving." },
          ].map((s, i) => (
            <motion.article
              key={s.title}
              initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.2 }} variants={fadeUp} custom={i}
              className="group relative overflow-hidden rounded-2xl border border-border/60 bg-card hover-lift"
            >
              <div className="relative aspect-[4/5] overflow-hidden">
                <img
                  src={s.img}
                  alt={s.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-[1500ms] group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
                <div className="absolute top-4 left-4 flex h-10 w-10 items-center justify-center rounded-full glass">
                  <s.icon className="h-4 w-4 text-gold" />
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-display text-2xl">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
                <Link to="/repair" className="mt-5 inline-flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-gold"
                >
                  Get a quote <ArrowRight className="h-3 w-3" />
                </Link>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      {/* PROCESS */}
      <section className="relative bg-card/40 border-y border-border/50 py-28">
        <div className="mx-auto max-w-7xl px-6">
          <motion.div
            initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}
            className="text-center max-w-2xl mx-auto"
          >
            <p className="text-xs uppercase tracking-[0.3em] text-gold">Our Process</p>
            <h2 className="mt-4 font-display text-5xl">Effortless from start to finish.</h2>
          </motion.div>

          <div className="mt-16 grid md:grid-cols-4 gap-8 relative">
            <div className="hidden md:block absolute top-8 left-[12%] right-[12%] h-px bg-gradient-to-r from-transparent via-gold/40 to-transparent" />
            {[
              { n: "01", t: "Order Online", d: "Select your service & receive a prepaid, insured shipping label." },
              { n: "02", t: "Mail It In", d: "Drop your piece at any UPS location — fully tracked, fully insured." },
              { n: "03", t: "Master Repair", d: "Our jewelers diagnose, restore, and quality-check every detail." },
              { n: "04", t: "Returned Sparkling", d: "Insured return shipping in 7–14 days with a satisfaction guarantee." },
            ].map((p, i) => (
              <motion.div
                key={p.n}
                initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} custom={i}
                className="relative text-center"
              >
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-gold/30 bg-background font-display text-xl text-gold">
                  {p.n}
                </div>
                <h3 className="mt-6 font-display text-xl">{p.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{p.d}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="mx-auto max-w-7xl px-6 py-28">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
          <p className="text-xs uppercase tracking-[0.3em] text-gold">Praise</p>
          <h2 className="mt-4 font-display text-5xl">Loved by collectors & sentimentalists.</h2>
        </motion.div>

        <div className="mt-12 grid md:grid-cols-3 gap-6">
          {[
            { q: "My grandmother's ring came back better than new. The packaging alone felt like jewelry.", n: "Eleanor R.", c: "New York" },
            { q: "Had my Submariner serviced — meticulous work, transparent pricing, returned ahead of schedule.", n: "Marcus T.", c: "San Francisco" },
            { q: "I was nervous mailing a $12k bracelet. Their insured shipping and updates put me at ease.", n: "Priya N.", c: "Chicago" },
          ].map((t, i) => (
            <motion.figure
              key={t.n}
              initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} custom={i}
              className="glass rounded-2xl p-8 hover-lift"
            >
              <div className="flex gap-1 text-gold">
                {Array.from({ length: 5 }).map((_, j) => <Star key={j} className="h-4 w-4 fill-current" />)}
              </div>
              <blockquote className="mt-5 font-display text-xl leading-snug text-foreground/90">"{t.q}"</blockquote>
              <figcaption className="mt-6 text-sm text-muted-foreground">
                <span className="text-foreground">{t.n}</span> · {t.c}
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="relative mx-auto max-w-7xl px-6 pb-24">
        <div className="relative overflow-hidden rounded-3xl border border-gold/20 p-12 md:p-20 text-center shadow-luxe">
          <div className="absolute inset-0 -z-10">
            <img src={heroImg} alt="" loading="lazy" className="h-full w-full object-cover opacity-25" />
            <div className="absolute inset-0 bg-gradient-to-br from-background via-background/85 to-background" />
          </div>
          <p className="text-xs uppercase tracking-[0.3em] text-gold">Begin</p>
          <h2 className="mt-4 font-display text-4xl md:text-6xl">Restore what matters most.</h2>
          <p className="mt-6 mx-auto max-w-xl text-muted-foreground">
            Get an instant quote and schedule your insured pickup in under two minutes.
          </p>
          <Link to="/repair" className="mt-10 inline-flex items-center gap-2 rounded-full bg-gold px-10 py-4 text-sm font-medium uppercase tracking-[0.2em] text-primary-foreground shadow-gold transition-all duration-500 hover:scale-105"
          >
            Start Your Repair <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}
