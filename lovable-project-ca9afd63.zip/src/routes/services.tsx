import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { Search, Plus, Heart, Star, ShoppingCart, Lock, ArrowRight } from "lucide-react";
import { SERVICES, CATEGORIES, CATEGORY_IMAGE, type CategoryId } from "@/lib/services-catalog";
import { useAuth } from "@/hooks/useAuth";
import { addToCart, readWish, toggleWish, onWishChange, syncWishFromDb, cartCount, onCartChange } from "@/lib/cart-store";
import { toast } from "sonner";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services Catalog — Quality Jewelry Repair" },
      { name: "description", content: "Browse our full catalog of jewelry and watch repair services. Transparent flat pricing, insured mail-in shipping, and master craftsmanship." },
      { property: "og:title", content: "Services Catalog — Quality Jewelry Repair" },
      { property: "og:description", content: "Browse our full catalog of jewelry and watch repair services with transparent flat pricing." },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<CategoryId>("all");
  const [q, setQ] = useState("");
  const [wish, setWish] = useState<{ id: string }[]>([]);
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!user) { setWish([]); setCount(0); return; }
    setWish(readWish(user.id));
    setCount(cartCount(user.id));
    syncWishFromDb(user.id).then((items) => setWish(items));
    const off1 = onWishChange(() => setWish(readWish(user.id)));
    const off2 = onCartChange(() => setCount(cartCount(user.id)));
    return () => { off1(); off2(); };
  }, [user?.id]);

  const visible = useMemo(() => {
    let list = SERVICES;
    if (filter === "popular") list = list.filter((s) => s.popular);
    else if (filter !== "all") list = list.filter((s) => s.category === filter);
    if (q) {
      const lo = q.toLowerCase().slice(0, 100);
      list = list.filter((s) => `${s.name} ${s.desc} ${s.category}`.toLowerCase().includes(lo));
    }
    return list;
  }, [filter, q]);

  const isWished = (id: string) => wish.some((w) => w.id === id);

  const requireLogin = () => {
    toast.info("Please sign in to continue");
    navigate({ to: "/login", search: { redirect: "/services" } as never });
  };

  const onAdd = (id: string) => {
    if (!user) return requireLogin();
    const s = SERVICES.find((x) => x.id === id)!;
    addToCart(user.id, { id: s.id, title: s.name, category: s.category, price: s.price, image: s.image });
    toast.success(`${s.name} added to cart`);
  };
  const onWish = async (id: string) => {
    if (!user) return requireLogin();
    const s = SERVICES.find((x) => x.id === id)!;
    const added = await toggleWish(user.id, { id: s.id, title: s.name, category: s.category, price: s.price, image: s.image });
    toast.success(added ? "Added to wishlist" : "Removed from wishlist");
  };

  return (
    <div className="mx-auto max-w-[88rem] px-4 sm:px-6 lg:px-10 py-10 sm:py-14">
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
        <p className="text-xs uppercase tracking-[0.3em] text-gold">Catalog</p>
        <div className="mt-3 flex flex-wrap items-end justify-between gap-4">
          <h1 className="font-display text-4xl sm:text-5xl md:text-6xl">Services Available</h1>
          {user && (
            <Link to="/account" hash="cart" className="inline-flex items-center gap-2 rounded-full bg-gold px-5 py-2.5 text-xs uppercase tracking-[0.2em] text-primary-foreground shadow-gold">
              <ShoppingCart className="h-3.5 w-3.5" /> View Cart{count > 0 ? ` (${count})` : ""}
            </Link>
          )}
        </div>
        <p className="mt-4 max-w-2xl text-muted-foreground">
          Master craftsmanship with transparent flat pricing. Add what you need to your cart and check out securely from your account.
        </p>
      </motion.div>

      <div className="mt-8 grid lg:grid-cols-[260px_1fr] gap-6 lg:gap-10">
        {/* Sidebar */}
        <aside className="lg:sticky lg:top-28 h-fit space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search services…"
              maxLength={100}
              className="w-full rounded-full border border-border bg-card pl-10 pr-4 py-2.5 text-sm focus:border-gold focus:outline-none"
            />
          </div>
          <div className="rounded-2xl border border-border bg-card p-4">
            <h3 className="font-display text-lg">Categories</h3>
            <div className="gold-divider my-3" />
            <ul className="flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible">
              {CATEGORIES.map((c) => {
                const active = filter === c.id;
                const count = c.id === "all" ? SERVICES.length : c.id === "popular" ? SERVICES.filter((s) => s.popular).length : SERVICES.filter((s) => s.category === c.id).length;
                return (
                  <li key={c.id} className="shrink-0">
                    <button
                      onClick={() => setFilter(c.id)}
                      className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-sm whitespace-nowrap transition-colors ${active ? "bg-gold/15 text-gold border border-gold/40" : "hover:bg-muted/40 border border-transparent text-foreground/80"}`}
                    >
                      <span className="flex items-center gap-2"><c.icon className="h-3.5 w-3.5" /> {c.label}</span>
                      <span className="text-[10px] tracking-widest text-muted-foreground hidden lg:inline">{count}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
          {!user && (
            <div className="rounded-2xl border border-gold/30 bg-card p-4 text-sm">
              <p className="flex items-center gap-2 text-xs uppercase tracking-widest text-gold"><Lock className="h-3.5 w-3.5" /> Login required</p>
              <p className="mt-2 text-muted-foreground">Sign in to add items to your cart or wishlist and place an order.</p>
              <Link to="/login" search={{ redirect: "/services" } as never} className="mt-3 inline-flex items-center gap-2 rounded-full bg-gold px-4 py-2 text-[11px] uppercase tracking-[0.2em] text-primary-foreground">
                Sign In <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
          )}
        </aside>

        {/* Grid */}
        <div className="min-w-0">
          <div className="flex items-baseline justify-between mb-4">
            <h2 className="font-display text-2xl sm:text-3xl">{CATEGORIES.find((c) => c.id === filter)?.label}</h2>
            <span className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{visible.length} services</span>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
            {visible.map((s, i) => (
              <motion.div
                key={s.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: Math.min(i * 0.02, 0.3) }}
                className="group rounded-2xl border border-border bg-card overflow-hidden hover-lift flex flex-col"
              >
                <div className="relative aspect-[4/3] overflow-hidden bg-muted">
                  <img src={s.image || CATEGORY_IMAGE[s.category]} alt={s.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                  {s.popular && (
                    <span className="absolute top-3 left-3 inline-flex items-center gap-1 rounded-full bg-gold/95 px-2.5 py-1 text-[10px] uppercase tracking-[0.2em] text-primary-foreground">
                      <Star className="h-3 w-3" /> Popular
                    </span>
                  )}
                  <button
                    onClick={() => onWish(s.id)}
                    aria-label="Toggle wishlist"
                    className={`absolute top-3 right-3 h-9 w-9 rounded-full grid place-items-center backdrop-blur transition-colors ${isWished(s.id) ? "bg-destructive text-destructive-foreground" : "bg-background/80 text-foreground/70 hover:text-destructive"}`}
                  >
                    <Heart className={`h-4 w-4 ${isWished(s.id) ? "fill-current" : ""}`} />
                  </button>
                </div>
                <div className="p-4 flex-1 flex flex-col">
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="font-display text-base leading-tight">{s.name}</h3>
                    <div className="font-display text-lg text-gold shrink-0">${s.price.toFixed(2)}</div>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{s.desc}</p>
                  <button
                    onClick={() => onAdd(s.id)}
                    className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-full bg-foreground/95 px-4 py-2 text-[11px] uppercase tracking-[0.2em] text-background hover:bg-gold transition-colors"
                  >
                    <Plus className="h-3.5 w-3.5" /> {user ? "Add to Cart" : "Sign In to Order"}
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
          {visible.length === 0 && (
            <p className="text-center py-12 text-sm text-muted-foreground">No services match your search.</p>
          )}
        </div>
      </div>
    </div>
  );
}
