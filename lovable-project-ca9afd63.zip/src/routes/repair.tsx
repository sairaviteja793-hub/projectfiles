import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { Check, Lock, ShieldCheck, ArrowRight, Plus, Minus, Trash2, Star, Heart, Loader2, ShoppingBag } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { SERVICES, CATEGORIES, type CategoryId } from "@/lib/services-catalog";
import {
  readCart, writeCart, addToCart, updateCartQty, removeFromCart, clearCart, onCartChange,
  readWish, toggleWish, onWishChange, syncWishFromDb,
} from "@/lib/cart-store";

export const Route = createFileRoute("/repair")({
  head: () => ({
    meta: [
      { title: "Start Your Repair — Quality Jewelry Repair" },
      { name: "description", content: "Browse repair services, add to cart, and place a secure order from your account." },
    ],
  }),
  component: RepairPage,
});

function RepairPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<CategoryId>("all");
  const [cart, setCart] = useState(() => readCart(user?.id));
  const [wish, setWish] = useState(() => readWish(user?.id));
  const [step, setStep] = useState<"select" | "details" | "review" | "done">("select");
  const [details, setDetails] = useState({ name: "", email: "", phone: "", address: "", notes: "" });
  const [submitting, setSubmitting] = useState(false);

  // Login gate
  useEffect(() => {
    if (!loading && !user) {
      toast.info("Please sign in to start your repair");
      navigate({ to: "/login", search: { redirect: "/repair" } as never });
    }
  }, [loading, user, navigate]);

  // Sync cart + wishlist with localStorage; pull wishlist from DB
  useEffect(() => {
    if (!user) return;
    setCart(readCart(user.id));
    setWish(readWish(user.id));
    syncWishFromDb(user.id).then((items) => setWish(items));
    const off1 = onCartChange(() => setCart(readCart(user.id)));
    const off2 = onWishChange(() => setWish(readWish(user.id)));
    return () => { off1(); off2(); };
  }, [user?.id]);

  // Prefill details from profile
  useEffect(() => {
    if (!user) return;
    setDetails((d) => ({ ...d, email: user.email || d.email }));
    supabase.from("profiles").select("full_name,phone").eq("id", user.id).maybeSingle().then(({ data }) => {
      if (data) setDetails((d) => ({ ...d, name: d.name || data.full_name || "", phone: d.phone || data.phone || "" }));
    });
  }, [user?.id]);

  const visible = useMemo(() => {
    if (filter === "all") return SERVICES;
    if (filter === "popular") return SERVICES.filter((s) => s.popular);
    return SERVICES.filter((s) => s.category === filter);
  }, [filter]);

  const items = cart.map((c) => ({
    service: SERVICES.find((s) => s.id === c.id) ?? { id: c.id, name: c.title, price: c.price, category: c.category, desc: "", image: c.image || "" },
    qty: c.qty,
  }));
  const subtotal = cart.reduce((sum, c) => sum + c.price * c.qty, 0);
  const total = subtotal;

  if (loading || !user) {
    return <div className="grid min-h-[60vh] place-items-center"><Loader2 className="h-6 w-6 animate-spin text-gold" /></div>;
  }

  const add = (id: string) => {
    const s = SERVICES.find((x) => x.id === id);
    if (!s) return;
    addToCart(user.id, { id: s.id, title: s.name, category: s.category, price: s.price, image: s.image });
    toast.success(`${s.name} added`);
  };
  const sub = (id: string) => {
    const c = readCart(user.id).find((x) => x.id === id);
    updateCartQty(user.id, id, (c?.qty ?? 0) - 1);
  };
  const inc = (id: string) => {
    const c = readCart(user.id).find((x) => x.id === id);
    updateCartQty(user.id, id, (c?.qty ?? 0) + 1);
  };
  const remove = (id: string) => removeFromCart(user.id, id);

  const isWished = (id: string) => wish.some((w) => w.id === id);
  const toggle = async (id: string) => {
    const s = SERVICES.find((x) => x.id === id);
    if (!s) return;
    const added = await toggleWish(user.id, { id: s.id, title: s.name, category: s.category, price: s.price, image: s.image });
    toast.success(added ? "Added to wishlist" : "Removed from wishlist");
  };

  const placeOrder = async () => {
    if (submitting) return;
    if (!details.name.trim()) return toast.error("Please enter your name");
    if (cart.length === 0) return toast.error("Cart is empty");
    setSubmitting(true);
    const { error } = await supabase.from("bookings").insert({
      user_id: user.id,
      customer_name: details.name.trim().slice(0, 100),
      customer_email: (details.email || user.email || "").trim().slice(0, 255),
      customer_phone: details.phone.trim().slice(0, 30) || null,
      customer_address: details.address.trim().slice(0, 500) || null,
      notes: details.notes.trim().slice(0, 1000) || null,
      total,
      status: "pending",
      items: items.map((i) => ({ id: i.service.id, title: i.service.name, category: i.service.category, price: i.service.price, qty: i.qty })),
    });
    setSubmitting(false);
    if (error) return toast.error(error.message);
    clearCart(user.id);
    toast.success("Order placed — we'll be in touch shortly");
    setStep("done");
  };

  return (
    <div className="mx-auto max-w-[88rem] px-4 sm:px-6 lg:px-10 py-10 sm:py-16">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
        <p className="text-xs uppercase tracking-[0.3em] text-gold">Begin</p>
        <h1 className="mt-3 font-display text-4xl sm:text-5xl md:text-6xl">Start Your Repair</h1>
        <p className="mt-4 max-w-2xl text-muted-foreground">
          Browse our services, add what you need to your cart, then review and place your order. Our jewelers handle the rest.
        </p>
        <div className="mt-4 flex flex-wrap items-center gap-3 text-xs uppercase tracking-[0.2em] text-muted-foreground">
          <span className="inline-flex items-center gap-1.5"><Lock className="h-3.5 w-3.5 text-gold" /> Signed in as {user.email}</span>
          <Link to="/account" hash="orders" className="rounded-full border border-border px-3 py-1.5 hover:border-gold hover:text-gold transition-colors">My Account</Link>
        </div>
      </motion.div>

      {/* Step indicator */}
      <div className="mt-8 sm:mt-10 flex flex-wrap items-center gap-3 text-xs uppercase tracking-[0.25em]">
        {(["select", "details", "review", "done"] as const).map((s, i) => {
          const active = step === s;
          const done = ["select", "details", "review", "done"].indexOf(step) > i;
          return (
            <div key={s} className="flex items-center gap-3">
              <span className={`flex h-8 w-8 items-center justify-center rounded-full border ${active ? "border-gold bg-gold text-primary-foreground" : done ? "border-gold/50 text-gold" : "border-border text-muted-foreground"}`}>
                {done ? <Check className="h-3.5 w-3.5" /> : i + 1}
              </span>
              <span className={active ? "text-foreground" : "text-muted-foreground"}>
                {s === "select" ? "Services" : s === "details" ? "Details" : s === "review" ? "Review" : "Confirmed"}
              </span>
              {i < 3 && <span className="hidden md:inline-block h-px w-10 bg-border" />}
            </div>
          );
        })}
      </div>

      <div className="mt-10 grid lg:grid-cols-[240px_1fr_340px] gap-6">
        {/* Sidebar categories */}
        {step === "select" && (
          <aside className="lg:sticky lg:top-28 h-fit rounded-2xl border border-border bg-card p-4 overflow-x-auto">
            <h3 className="font-display text-lg">Categories</h3>
            <div className="gold-divider my-3" />
            <ul className="flex lg:flex-col gap-1 lg:gap-0 lg:space-y-1">
              {CATEGORIES.map((c) => {
                const active = filter === c.id;
                const count = c.id === "all" ? SERVICES.length : c.id === "popular" ? SERVICES.filter((s) => s.popular).length : SERVICES.filter((s) => s.category === c.id).length;
                return (
                  <li key={c.id} className="shrink-0">
                    <button onClick={() => setFilter(c.id)} className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-sm transition-colors ${active ? "bg-gold/15 text-gold border border-gold/40" : "hover:bg-muted/40 border border-transparent text-foreground/80"}`}>
                      <span className="flex items-center gap-2 whitespace-nowrap"><c.icon className="h-3.5 w-3.5" />{c.label}</span>
                      <span className="text-[10px] tracking-widest text-muted-foreground hidden lg:inline">{count}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </aside>
        )}

        <div className={step === "select" ? "min-w-0" : "lg:col-span-2 min-w-0"}>
          {step === "select" && (
            <>
              <div className="flex items-baseline justify-between">
                <h2 className="font-display text-2xl sm:text-3xl">{CATEGORIES.find((c) => c.id === filter)?.label}</h2>
                <span className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{visible.length} services</span>
              </div>
              <div className="gold-divider my-4" />

              <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-5">
                {visible.map((s, i) => (
                  <motion.div key={s.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: Math.min(i * 0.02, 0.3) }} className="group rounded-2xl border border-border bg-card overflow-hidden hover-lift flex flex-col">
                    <div className="relative aspect-[4/3] overflow-hidden bg-muted">
                      <img src={s.image} alt={s.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                      {s.popular && (
                        <span className="absolute top-3 left-3 inline-flex items-center gap-1 rounded-full bg-gold/95 px-2.5 py-1 text-[10px] uppercase tracking-[0.2em] text-primary-foreground">
                          <Star className="h-3 w-3" /> Popular
                        </span>
                      )}
                      <button onClick={() => toggle(s.id)} aria-label="Toggle wishlist" className={`absolute top-3 right-3 h-9 w-9 rounded-full grid place-items-center backdrop-blur transition-colors ${isWished(s.id) ? "bg-destructive text-destructive-foreground" : "bg-background/80 text-foreground/70 hover:text-destructive"}`}>
                        <Heart className={`h-4 w-4 ${isWished(s.id) ? "fill-current" : ""}`} />
                      </button>
                    </div>
                    <div className="p-4 sm:p-5 flex-1 flex flex-col">
                      <div className="flex items-start justify-between gap-3">
                        <h3 className="font-display text-lg leading-tight">{s.name}</h3>
                        <div className="text-right shrink-0">
                          <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">From</div>
                          <div className="font-display text-xl text-gold leading-none">${s.price.toFixed(2)}</div>
                        </div>
                      </div>
                      <p className="mt-2 text-xs text-muted-foreground line-clamp-2">{s.desc}</p>
                      <button onClick={() => add(s.id)} className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-foreground/95 px-4 py-2 text-[11px] uppercase tracking-[0.2em] text-background hover:bg-gold transition-colors">
                        <Plus className="h-3.5 w-3.5" /> Add to Cart
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </>
          )}

          {step === "details" && (
            <form onSubmit={(e) => { e.preventDefault(); setStep("review"); }} className="space-y-5 max-w-xl">
              <h2 className="font-display text-2xl">Your Details</h2>
              {[
                { k: "name", label: "Full Name *", type: "text", req: true, max: 100 },
                { k: "email", label: "Email Address *", type: "email", req: true, max: 255 },
                { k: "phone", label: "Phone Number", type: "tel", req: false, max: 30 },
                { k: "address", label: "Return Shipping Address", type: "text", req: false, max: 500 },
              ].map((f) => (
                <div key={f.k}>
                  <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{f.label}</label>
                  <input required={f.req} maxLength={f.max} type={f.type} value={(details as any)[f.k]} onChange={(e) => setDetails({ ...details, [f.k]: e.target.value })} className="mt-1 w-full rounded-lg border border-border bg-card px-4 py-3 focus:border-gold focus:outline-none" />
                </div>
              ))}
              <div>
                <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Notes for our jewelers</label>
                <textarea rows={4} maxLength={1000} value={details.notes} onChange={(e) => setDetails({ ...details, notes: e.target.value })} className="mt-1 w-full rounded-lg border border-border bg-card px-4 py-3 focus:border-gold focus:outline-none" />
              </div>
              <div className="flex gap-3">
                <button type="button" onClick={() => setStep("select")} className="rounded-full border border-border px-6 py-3 text-xs uppercase tracking-[0.2em] hover:border-gold">Back</button>
                <button type="submit" className="inline-flex items-center gap-2 rounded-full bg-gold px-8 py-3 text-xs uppercase tracking-[0.2em] text-primary-foreground shadow-gold hover:scale-105 transition-transform">Review Order <ArrowRight className="h-3.5 w-3.5" /></button>
              </div>
            </form>
          )}

          {step === "review" && (
            <div className="max-w-xl space-y-5">
              <div className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-gold">
                <Lock className="h-3.5 w-3.5" /> Secure checkout
              </div>
              <h2 className="font-display text-2xl">Review & Confirm</h2>
              <div className="rounded-2xl border border-border bg-card p-5 space-y-3">
                <h3 className="font-display text-lg">Customer</h3>
                <p className="text-sm">{details.name}</p>
                <p className="text-sm text-muted-foreground">{details.email}{details.phone ? ` · ${details.phone}` : ""}</p>
                {details.address && <p className="text-sm text-muted-foreground">{details.address}</p>}
              </div>
              <div className="rounded-2xl border border-border bg-card p-5">
                <h3 className="font-display text-lg mb-3">Items</h3>
                <ul className="space-y-2 text-sm">
                  {items.map(({ service, qty }) => (
                    <li key={service.id} className="flex justify-between gap-3">
                      <span className="min-w-0 truncate">{service.name} × {qty}</span>
                      <span className="shrink-0">${(service.price * qty).toFixed(2)}</span>
                    </li>
                  ))}
                </ul>
                <hr className="my-3 border-border" />
                <p className="flex justify-between font-display text-xl">Total <span className="text-gold">${total.toFixed(2)}</span></p>
                <p className="mt-2 text-xs text-muted-foreground">Payment is collected on receipt of your item or at pickup.</p>
              </div>
              <div className="flex gap-3">
                <button type="button" onClick={() => setStep("details")} className="rounded-full border border-border px-6 py-3 text-xs uppercase tracking-[0.2em] hover:border-gold">Back</button>
                <button disabled={submitting} onClick={placeOrder} className="inline-flex items-center gap-2 rounded-full bg-gold px-8 py-3 text-xs uppercase tracking-[0.2em] text-primary-foreground shadow-gold hover:scale-105 transition-transform disabled:opacity-60">
                  <ShieldCheck className="h-4 w-4" /> {submitting ? "Placing…" : "Place Order"}
                </button>
              </div>
            </div>
          )}

          {step === "done" && (
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="glass rounded-2xl p-8 sm:p-10 text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-gold/15 border border-gold/40">
                <Check className="h-7 w-7 text-gold" />
              </div>
              <h2 className="mt-6 font-display text-2xl sm:text-3xl">Order Confirmed</h2>
              <p className="mt-3 text-muted-foreground">Thank you, {details.name || "valued customer"}. Track your order anytime under "My Orders".</p>
              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <Link to="/account" hash="orders" className="inline-flex items-center gap-2 rounded-full bg-gold px-6 py-3 text-xs uppercase tracking-[0.2em] text-primary-foreground shadow-gold">
                  <ShoppingBag className="h-4 w-4" /> View My Orders
                </Link>
                <button onClick={() => { setStep("select"); }} className="rounded-full border border-border px-6 py-3 text-xs uppercase tracking-[0.2em] hover:border-gold">Continue Shopping</button>
              </div>
            </motion.div>
          )}
        </div>

        {/* Cart sidebar */}
        <aside className="lg:sticky lg:top-28 h-fit rounded-2xl border border-border bg-card p-5 sm:p-6 shadow-luxe">
          <h3 className="font-display text-xl sm:text-2xl flex items-center gap-2"><ShoppingBag className="h-5 w-5 text-gold" /> Your Cart</h3>
          <div className="gold-divider my-4" />
          {items.length === 0 ? (
            <p className="text-sm text-muted-foreground">Cart is empty. Add services to get started.</p>
          ) : (
            <ul className="space-y-3 max-h-72 overflow-auto pr-1">
              {items.map(({ service, qty }) => (
                <li key={service.id} className="flex items-center justify-between gap-3 text-sm">
                  <div className="flex-1 min-w-0">
                    <div className="truncate">{service.name}</div>
                    <div className="text-xs text-muted-foreground">${service.price.toFixed(2)} × {qty}</div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button onClick={() => sub(service.id)} className="h-7 w-7 grid place-items-center rounded-full border border-border hover:border-gold"><Minus className="h-3 w-3" /></button>
                    <span className="w-6 text-center">{qty}</span>
                    <button onClick={() => inc(service.id)} className="h-7 w-7 grid place-items-center rounded-full border border-border hover:border-gold"><Plus className="h-3 w-3" /></button>
                    <button onClick={() => remove(service.id)} className="h-7 w-7 grid place-items-center rounded-full border border-border hover:border-destructive text-muted-foreground hover:text-destructive ml-1"><Trash2 className="h-3 w-3" /></button>
                  </div>
                </li>
              ))}
            </ul>
          )}
          <div className="gold-divider my-4" />
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between"><dt className="text-muted-foreground">Subtotal</dt><dd>${subtotal.toFixed(2)}</dd></div>
            <div className="flex justify-between"><dt className="text-muted-foreground">Insured Shipping</dt><dd className="text-gold">Free</dd></div>
            <div className="flex justify-between font-display text-xl mt-2"><dt>Total</dt><dd className="text-gold">${total.toFixed(2)}</dd></div>
          </dl>

          {step === "select" && (
            <button disabled={items.length === 0} onClick={() => setStep("details")} className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gold px-6 py-3 text-xs uppercase tracking-[0.2em] text-primary-foreground shadow-gold disabled:opacity-40 disabled:cursor-not-allowed hover:scale-[1.02] transition-transform">
              Checkout <ArrowRight className="h-3.5 w-3.5" />
            </button>
          )}

          <div className="mt-6 flex items-center gap-2 text-[11px] uppercase tracking-widest text-muted-foreground">
            <Lock className="h-3 w-3 text-gold" /> Encrypted & login-protected
          </div>
        </aside>
      </div>
    </div>
  );
}
