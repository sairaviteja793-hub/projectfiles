import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState } from "react";
import { Lock, Mail, User, Eye, EyeOff, Gem, Check, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Create Account — Quality Jewelry Repair" },
      { name: "description", content: "Register for premium mail-in jewelry & watch repair." },
    ],
  }),
  component: SignupPage,
});

function SignupPage() {
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "", confirm: "" });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password.length < 8) return toast.error("Password must be at least 8 characters.");
    if (form.password !== form.confirm) return toast.error("Passwords don't match.");
    setLoading(true);
    const redirect = `${window.location.origin}/`;
    const { error } = await supabase.auth.signUp({
      email: form.email,
      password: form.password,
      options: { data: { full_name: form.name }, emailRedirectTo: redirect },
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Account created");
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("role", "admin")
      .maybeSingle();
    navigate({ to: data ? "/admin" : "/repair" });
  };

  return (
    <div className="mx-auto grid min-h-[80vh] max-w-6xl place-items-center px-6 py-16">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="w-full max-w-md">
        <div className="text-center">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-full border border-gold/40">
            <Gem className="h-6 w-6 text-gold" />
          </div>
          <h1 className="mt-5 font-display text-4xl">Create Your Account</h1>
          <p className="mt-2 text-sm text-muted-foreground">Join 200,000+ collectors trusting us with their pieces.</p>
        </div>

        <form onSubmit={submit} className="mt-10 glass rounded-2xl p-8 space-y-5">
          <Field label="Full Name" icon={<User className="h-4 w-4" />}>
            <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="qjr-input" />
          </Field>
          <Field label="Email" icon={<Mail className="h-4 w-4" />}>
            <input type="email" required autoComplete="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="qjr-input" />
          </Field>
          <Field label="Password" icon={<Lock className="h-4 w-4" />}>
            <input type={show ? "text" : "password"} required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} className="qjr-input pr-10" />
            <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </Field>
          <Field label="Confirm Password" icon={<Lock className="h-4 w-4" />}>
            <input type={show ? "text" : "password"} required value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} className="qjr-input" />
          </Field>

          <ul className="text-xs text-muted-foreground space-y-1">
            <li className="flex items-center gap-2"><Check className="h-3 w-3 text-gold" /> 8+ characters with mixed case recommended</li>
            <li className="flex items-center gap-2"><Check className="h-3 w-3 text-gold" /> Your data is encrypted end-to-end</li>
          </ul>

          <button disabled={loading} type="submit" className="w-full rounded-full bg-gold py-3 text-xs uppercase tracking-[0.25em] text-primary-foreground shadow-gold hover:scale-[1.02] transition-transform disabled:opacity-60 inline-flex items-center justify-center gap-2">
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            Create Account
          </button>

          <p className="text-center text-sm text-muted-foreground">
            Already a member? <Link to="/login" className="text-gold hover:underline">Sign in</Link>
          </p>
        </form>
      </motion.div>
    </div>
  );
}

function Field({ label, icon, children }: { label: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{label}</label>
      <div className="mt-1 relative">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">{icon}</span>
        {children}
      </div>
    </div>
  );
}
