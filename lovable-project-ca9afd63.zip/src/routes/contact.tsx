import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Mail, MapPin, Clock, Send } from "lucide-react";
import { useState } from "react";
import { z } from "zod";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Quality Jewelry Repair" },
      { name: "description", content: "Reach our concierge team for repair questions, custom quotes, or order support." },
    ],
  }),
  component: ContactPage,
});

const schema = z.object({
  name: z.string().trim().min(1, "Required").max(100),
  email: z.string().trim().email("Invalid email").max(255),
  subject: z.string().trim().min(1, "Required").max(150),
  message: z.string().trim().min(1, "Required").max(2000),
});

export default function ContactPage() {
  const [status, setStatus] = useState<"idle" | "sent" | "error">("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const parsed = schema.safeParse(data);
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      parsed.error.issues.forEach((i) => { fieldErrors[i.path[0] as string] = i.message; });
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    // Simulate send (no backend wired). Replace with server fn for real submissions.
    setStatus("sent");
    e.currentTarget.reset();
  };

  return (
    <div className="mx-auto max-w-6xl px-6 py-20">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
        <p className="text-xs uppercase tracking-[0.3em] text-gold">Concierge</p>
        <h1 className="mt-4 font-display text-5xl md:text-7xl">Contact Us</h1>
        <p className="mt-6 max-w-xl text-lg text-muted-foreground">
          Questions about a repair, a custom request, or an existing order? Our team responds within one business day.
        </p>
      </motion.div>

      <div className="mt-16 grid md:grid-cols-[1fr_1.4fr] gap-10">
        <div className="space-y-6">
          {[
            { icon: Mail, t: "Email", v: "support@qualityjewelryrepairs.com" },
            { icon: Clock, t: "Hours", v: "Monday–Friday · 9am–6pm EST" },
            { icon: MapPin, t: "Atelier", v: "Mail-in service nationwide" },
          ].map((c) => (
            <div key={c.t} className="glass rounded-2xl p-6 flex items-start gap-4 hover-lift">
              <c.icon className="h-5 w-5 text-gold mt-0.5" />
              <div>
                <div className="text-xs uppercase tracking-[0.2em] text-gold">{c.t}</div>
                <div className="mt-1 text-foreground">{c.v}</div>
              </div>
            </div>
          ))}
        </div>

        <motion.form
          onSubmit={onSubmit}
          initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.15 }}
          className="glass rounded-2xl p-8 space-y-5"
        >
          {(["name", "email", "subject"] as const).map((f) => (
            <div key={f}>
              <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground capitalize">{f}</label>
              <input
                name={f}
                type={f === "email" ? "email" : "text"}
                maxLength={f === "email" ? 255 : f === "subject" ? 150 : 100}
                required
                className="mt-2 w-full bg-transparent border-b border-border py-3 text-foreground outline-none focus:border-gold transition-colors"
              />
              {errors[f] && <p className="mt-1 text-xs text-destructive">{errors[f]}</p>}
            </div>
          ))}
          <div>
            <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Message</label>
            <textarea
              name="message"
              rows={5}
              maxLength={2000}
              required
              className="mt-2 w-full bg-transparent border-b border-border py-3 text-foreground outline-none focus:border-gold transition-colors resize-none"
            />
            {errors.message && <p className="mt-1 text-xs text-destructive">{errors.message}</p>}
          </div>
          <button
            type="submit"
            className="inline-flex items-center gap-2 rounded-full bg-gold px-8 py-3 text-sm font-medium uppercase tracking-[0.2em] text-primary-foreground shadow-gold hover:scale-105 transition-transform"
          >
            Send Message <Send className="h-4 w-4" />
          </button>
          {status === "sent" && (
            <p className="text-sm text-gold">Thank you — your message has been received. We'll reply within one business day.</p>
          )}
        </motion.form>
      </div>
    </div>
  );
}
