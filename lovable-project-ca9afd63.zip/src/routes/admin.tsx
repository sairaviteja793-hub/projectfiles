import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Shield, LayoutDashboard, Package, ShoppingBag, BarChart3, Megaphone, Settings,
  Plus, Pencil, Trash2, Loader2, Bell, CreditCard, Mail, Phone, Lock, Save, ChevronLeft, ChevronRight, Image as ImageIcon, Users, DollarSign, Send, Search, LogOut, Home, UserCog
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { CATEGORIES as PRESET_CATEGORIES } from "@/lib/services-catalog";
import { ThemeToggle } from "@/components/ThemeToggle";
import { TeamTab } from "@/components/admin/TeamTab";
import { UserHistoryDrawer } from "@/components/admin/UserHistoryDrawer";
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip as RTooltip, PieChart, Pie, Cell, Legend,
} from "recharts";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard — Quality Jewelry Repair" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: AdminPage,
});

type Tab = "dashboard" | "items" | "bookings" | "users" | "offline" | "email" | "notify" | "analytics" | "announcements" | "team" | "settings";

function AdminPage() {
  const { user, isAdmin, isStaff, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("dashboard");
  const [pendingCount, setPendingCount] = useState(0);

  const hasAccess = isAdmin || isStaff;

  useEffect(() => {
    if (!loading && (!user || !hasAccess)) navigate({ to: "/login" });
  }, [loading, user, hasAccess]);

  useEffect(() => {
    if (!user || !hasAccess) return;
    const refresh = async () => {
      const { count } = await supabase
        .from("bookings")
        .select("id", { count: "exact", head: true })
        .eq("status", "pending");
      setPendingCount(count ?? 0);
    };
    refresh();
    const ch = supabase
      .channel("admin-bookings")
      .on("postgres_changes", { event: "*", schema: "public", table: "bookings" }, refresh)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user, hasAccess]);

  if (loading) {
    return <div className="grid min-h-[60vh] place-items-center"><Loader2 className="h-6 w-6 animate-spin text-gold" /></div>;
  }
  if (!user || !hasAccess) return null;

  // Tabs visible to ALL admin/staff
  const baseTabs: { id: Tab; label: string; icon: any; badge?: number }[] = [
    { id: "dashboard", label: "Overview", icon: LayoutDashboard },
    { id: "items", label: "Services", icon: Package },
    { id: "bookings", label: "Repairs / Bookings", icon: ShoppingBag, badge: pendingCount },
    { id: "users", label: "Users", icon: Users },
    { id: "email", label: "Send Email", icon: Mail },
    { id: "notify", label: "Push to Users", icon: Send },
    { id: "announcements", label: "Announcements", icon: Megaphone },
  ];
  // Admin-only tabs (sales / analytics / team / payment settings)
  const adminOnlyTabs: { id: Tab; label: string; icon: any; badge?: number }[] = [
    { id: "offline", label: "Offline Sales", icon: DollarSign },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
    { id: "team", label: "Team / Staff", icon: UserCog },
    { id: "settings", label: "Settings", icon: Settings },
  ];
  const TABS = isAdmin ? [...baseTabs, ...adminOnlyTabs] : baseTabs;

  // Block staff from sneaking into admin-only tabs via state
  const safeTab: Tab = !isAdmin && (["offline","analytics","team","settings"] as Tab[]).includes(tab) ? "dashboard" : tab;

  return (
    <div className="mx-auto max-w-[88rem] px-4 sm:px-6 lg:px-10 py-6 sm:py-10">
      <header className="flex flex-wrap items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-3">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-gold/40">
            <Shield className="h-5 w-5 text-gold" />
          </div>
          <div>
            <h1 className="font-display text-2xl sm:text-3xl">Admin Dashboard</h1>
            <p className="text-[10px] sm:text-xs uppercase tracking-widest text-muted-foreground">Quality Jewelry Repair · Control Center</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Link to="/" className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-2 text-xs uppercase tracking-widest hover:bg-foreground/5"><Home className="h-3.5 w-3.5" /> Site</Link>
          <button onClick={signOut} className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-2 text-xs uppercase tracking-widest hover:bg-destructive/10 hover:text-destructive"><LogOut className="h-3.5 w-3.5" /> Sign Out</button>
        </div>
      </header>


      <div className="flex gap-6">
        {/* Sidebar */}
        <aside className="hidden md:block w-56 shrink-0">
          <nav className="glass rounded-xl p-2 sticky top-28 space-y-1">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${
                  tab === t.id ? "bg-gold text-primary-foreground" : "text-foreground/70 hover:bg-foreground/5"
                }`}
              >
                <t.icon className="h-4 w-4" />
                <span className="flex-1 text-left">{t.label}</span>
                {!!t.badge && t.badge > 0 && (
                  <span className={`inline-flex items-center justify-center min-w-[22px] h-[22px] px-1.5 rounded-full text-[10px] font-semibold ${tab === t.id ? "bg-primary-foreground/20 text-primary-foreground" : "bg-rose-500 text-white"}`}>
                    {t.badge > 99 ? "99+" : t.badge}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </aside>

        {/* Mobile tabs */}
        <div className="md:hidden -mx-4 px-4 overflow-x-auto pb-3 mb-4 flex gap-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`shrink-0 inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs ${
                tab === t.id ? "bg-gold text-primary-foreground border-gold" : "border-border text-foreground/70"
              }`}
            >
              {t.label}
              {!!t.badge && t.badge > 0 && (
                <span className="inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full text-[9px] font-semibold bg-rose-500 text-white">
                  {t.badge > 99 ? "99+" : t.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        <section className="flex-1 min-w-0">
          <motion.div key={safeTab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }}>
            {safeTab === "dashboard" && <Overview onNav={setTab} isAdmin={isAdmin} />}
            {safeTab === "items" && <ItemsManager />}
            {safeTab === "bookings" && <BookingsManager />}
            {safeTab === "users" && <UsersManager />}
            {safeTab === "offline" && isAdmin && <OfflineSalesManager />}
            {safeTab === "email" && <ManualEmailComposer />}
            {safeTab === "notify" && <PushToUsersManager />}
            {safeTab === "analytics" && isAdmin && <AnalyticsView />}
            {safeTab === "announcements" && <AnnouncementsManager />}
            {safeTab === "team" && isAdmin && <TeamTab />}
            {safeTab === "settings" && isAdmin && <SettingsView />}
          </motion.div>
        </section>
      </div>
    </div>
  );
}

/* ---------- Overview ---------- */
function Overview({ onNav, isAdmin }: { onNav: (t: Tab) => void; isAdmin: boolean }) {
  const [stats, setStats] = useState({ services: 0, bookings: 0, revenue: 0, announcements: 0 });

  useEffect(() => {
    (async () => {
      const [{ count: sC }, { data: bk }, { count: aC }] = await Promise.all([
        supabase.from("services").select("id", { count: "exact", head: true }),
        supabase.from("bookings").select("total"),
        supabase.from("announcements").select("id", { count: "exact", head: true }).eq("active", true),
      ]);
      const total = (bk ?? []).reduce((s, b: any) => s + Number(b.total || 0), 0);
      setStats({ services: sC ?? 0, bookings: bk?.length ?? 0, revenue: total, announcements: aC ?? 0 });
    })();
  }, []);

  const cards = [
    { label: "Total Services", value: stats.services, tab: "items" as Tab, color: "text-gold" },
    { label: "Total Bookings", value: stats.bookings, tab: "bookings" as Tab, color: "text-emerald-500" },
    ...(isAdmin ? [{ label: "Total Revenue", value: `$${stats.revenue.toFixed(2)}`, tab: "analytics" as Tab, color: "text-blue-500" }] : []),
    { label: "Active Banners", value: stats.announcements, tab: "announcements" as Tab, color: "text-rose-500" },
  ];

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map((c) => (
        <button key={c.label} onClick={() => onNav(c.tab)} className="glass rounded-xl p-6 text-left hover-lift">
          <p className="text-xs uppercase tracking-widest text-muted-foreground">{c.label}</p>
          <p className={`mt-3 font-display text-4xl ${c.color}`}>{c.value}</p>
        </button>
      ))}
    </div>
  );
}

/* ---------- Items / Services Manager ---------- */
interface Service { id: string; category: string; title: string; description: string | null; price: number; image_url: string | null; popular: boolean; active: boolean; sort_order: number; }

function ItemsManager() {
  const [items, setItems] = useState<Service[]>([]);
  const [editing, setEditing] = useState<Partial<Service> | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("services").select("*").order("sort_order");
    setItems((data as Service[]) ?? []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!editing) return;
    const payload = {
      category: editing.category || "General",
      title: editing.title || "Untitled",
      description: editing.description || null,
      price: Number(editing.price) || 0,
      image_url: editing.image_url || null,
      popular: !!editing.popular,
      active: editing.active !== false,
      sort_order: Number(editing.sort_order) || 999,
    };
    const { error } = editing.id
      ? await supabase.from("services").update(payload).eq("id", editing.id)
      : await supabase.from("services").insert(payload);
    if (error) return toast.error(error.message);
    toast.success(editing.id ? "Service updated" : "Service added");
    setEditing(null);
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this service?")) return;
    const { error } = await supabase.from("services").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    load();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-2xl">Services Catalog</h2>
        <button onClick={() => setEditing({ active: true, popular: false, price: 0, sort_order: items.length + 1 })} className="inline-flex items-center gap-2 rounded-full bg-gold px-4 py-2 text-xs uppercase tracking-widest text-primary-foreground">
          <Plus className="h-4 w-4" /> Add Service
        </button>
      </div>

      {loading ? (
        <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-gold" /></div>
      ) : (
        <div className="grid gap-3">
          {items.map((s) => (
            <div key={s.id} className="glass rounded-xl p-4 flex items-center gap-4">
              <div className="h-16 w-16 rounded-lg bg-muted overflow-hidden shrink-0 grid place-items-center">
                {s.image_url ? <img src={s.image_url} alt={s.title} className="h-full w-full object-cover" /> : <ImageIcon className="h-6 w-6 text-muted-foreground" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] uppercase tracking-widest text-gold">{s.category}</span>
                  {s.popular && <span className="text-[10px] rounded-full bg-rose-500/15 text-rose-500 px-2 py-0.5">Popular</span>}
                  {!s.active && <span className="text-[10px] rounded-full bg-muted px-2 py-0.5">Inactive</span>}
                </div>
                <p className="font-medium truncate">{s.title}</p>
                <p className="text-sm text-muted-foreground truncate">{s.description}</p>
              </div>
              <p className="font-display text-xl shrink-0">${Number(s.price).toFixed(2)}</p>
              <div className="flex gap-1 shrink-0">
                <button onClick={() => setEditing(s)} className="p-2 rounded-lg hover:bg-foreground/5"><Pencil className="h-4 w-4" /></button>
                <button onClick={() => remove(s.id)} className="p-2 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 backdrop-blur-sm p-4" onClick={() => setEditing(null)}>
          <div className="glass-strong rounded-2xl p-6 w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-display text-2xl mb-4">{editing.id ? "Edit Service" : "Add Service"}</h3>
            <div className="space-y-3">
              <Input label="Title" value={editing.title || ""} onChange={(v) => setEditing({ ...editing, title: v })} />
              <div>
                <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Category</label>
                <select
                  value={editing.category || ""}
                  onChange={(e) => setEditing({ ...editing, category: e.target.value })}
                  className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2.5 focus:border-gold focus:outline-none"
                >
                  <option value="">Select a category…</option>
                  {PRESET_CATEGORIES.filter((c) => c.id !== "all" && c.id !== "popular").map((c) => (
                    <option key={c.id} value={c.id}>{c.label}</option>
                  ))}
                </select>
              </div>
              <Input label="Description" value={editing.description || ""} onChange={(v) => setEditing({ ...editing, description: v })} />
              <div className="grid grid-cols-2 gap-3">
                <Input label="Price ($)" type="number" value={String(editing.price ?? 0)} onChange={(v) => setEditing({ ...editing, price: Number(v) })} />
                <Input label="Sort Order" type="number" value={String(editing.sort_order ?? 0)} onChange={(v) => setEditing({ ...editing, sort_order: Number(v) })} />
              </div>
              <Input label="Image URL" value={editing.image_url || ""} onChange={(v) => setEditing({ ...editing, image_url: v })} placeholder="https://..." />
              <div className="flex gap-4 text-sm">
                <label className="flex items-center gap-2"><input type="checkbox" checked={!!editing.popular} onChange={(e) => setEditing({ ...editing, popular: e.target.checked })} /> Popular</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={editing.active !== false} onChange={(e) => setEditing({ ...editing, active: e.target.checked })} /> Active</label>
              </div>
            </div>
            <div className="mt-6 flex gap-3 justify-end">
              <button onClick={() => setEditing(null)} className="px-4 py-2 text-sm rounded-full border border-border">Cancel</button>
              <button onClick={save} className="inline-flex items-center gap-2 rounded-full bg-gold px-4 py-2 text-xs uppercase tracking-widest text-primary-foreground"><Save className="h-4 w-4" /> Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- Bookings ---------- */
interface Booking { id: string; customer_name: string; customer_email: string; customer_phone: string | null; customer_address: string | null; total: number; status: string; items: any; created_at: string; notes: string | null; }
function BookingsManager() {
  const [items, setItems] = useState<Booking[]>([]);
  const [open, setOpen] = useState<Booking | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("bookings").select("*").order("created_at", { ascending: false });
    setItems((data as Booking[]) ?? []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);


  const notifyCustomer = async (b: Booking, statusOverride?: string) => {
    const status = statusOverride ?? b.status;
    const statusLabel = status.replace(/_/g, " ");
    if ("Notification" in window) {
      if (Notification.permission === "default") await Notification.requestPermission();
      if (Notification.permission === "granted") {
        new Notification(`Repair update for ${b.customer_name}`, { body: `Status: ${statusLabel}` });
      }
    }
    await supabase.from("user_notifications").insert({
      title: `Your repair is ${statusLabel}`,
      message: `Hi ${b.customer_name}, your order total $${Number(b.total).toFixed(2)} is now ${statusLabel}. We've emailed ${b.customer_email} with details.`,
    });
    // Open mail client as a lightweight email trigger (works without email infra)
    const subject = encodeURIComponent(`Your repair status: ${statusLabel}`);
    const body = encodeURIComponent(`Hi ${b.customer_name},\n\nYour repair (order total $${Number(b.total).toFixed(2)}) is now: ${statusLabel}.\n\nThank you,\nQuality Jewelry Repair`);
    try { window.open(`mailto:${b.customer_email}?subject=${subject}&body=${body}`, "_blank"); } catch {}
    toast.success(`Customer ${b.customer_email} notified`);
  };

  const setStatus = async (b: Booking, status: string) => {
    const { error } = await supabase.from("bookings").update({ status }).eq("id", b.id);
    if (error) return toast.error(error.message);
    toast.success("Status updated — emailing customer");
    await notifyCustomer(b, status);
    load();
  };


  return (
    <div>
      <h2 className="font-display text-2xl mb-4">Customer Bookings & Repair Status</h2>
      {loading ? (
        <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-gold" /></div>
      ) : items.length === 0 ? (
        <div className="glass rounded-xl p-10 text-center text-muted-foreground">No bookings yet.</div>
      ) : (
        <div className="space-y-3">
          {items.map((b) => (
            <div key={b.id} className="glass rounded-xl p-4 space-y-3">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <p className="font-medium truncate">{b.customer_name}</p>
                  <p className="text-xs sm:text-sm text-muted-foreground break-all">{b.customer_email}{b.customer_phone ? ` · ${b.customer_phone}` : ""}</p>
                  <p className="text-[10px] sm:text-xs text-muted-foreground mt-1">{new Date(b.created_at).toLocaleString()}</p>
                </div>
                <p className="font-display text-xl shrink-0">${Number(b.total).toFixed(2)}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <select value={b.status} onChange={(e) => setStatus(b, e.target.value)} className="flex-1 min-w-[150px] rounded-full border border-border bg-card px-3 py-1.5 text-xs">
                  <option value="pending">Pending</option>
                  <option value="received">Received</option>
                  <option value="in_progress">In Progress</option>
                  <option value="under_repair">Under Repair</option>
                  <option value="repair_completed">Repair Completed</option>
                  <option value="out_for_delivery">Out for Delivery</option>
                  <option value="delivered">Delivered</option>
                  <option value="cancelled">Cancelled</option>
                </select>
                <button onClick={() => notifyCustomer(b)} title="Send status notification" className="inline-flex items-center gap-1 rounded-full border border-gold/40 text-gold px-3 py-1.5 text-xs hover:bg-gold/10">
                  <Bell className="h-3 w-3" /> Notify
                </button>
                <button onClick={() => setOpen(b)} className="rounded-full border border-border px-3 py-1.5 text-xs">Details</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {open && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 backdrop-blur-sm p-4" onClick={() => setOpen(null)}>
          <div className="glass-strong rounded-2xl p-6 w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-display text-2xl">{open.customer_name}</h3>
            <p className="text-sm text-muted-foreground">{open.customer_email}</p>
            {open.customer_phone && <p className="text-sm text-muted-foreground">{open.customer_phone}</p>}
            {open.customer_address && <p className="text-sm text-muted-foreground mt-2">{open.customer_address}</p>}
            <hr className="my-4 border-border" />
            <p className="text-xs uppercase tracking-widest text-muted-foreground mb-2">Items</p>
            <ul className="space-y-2">
              {(open.items as any[]).map((it, i) => (
                <li key={i} className="flex justify-between text-sm">
                  <span>{it.title} <span className="text-muted-foreground">× {it.qty || 1}</span></span>
                  <span>${Number(it.price).toFixed(2)}</span>
                </li>
              ))}
            </ul>
            <hr className="my-4 border-border" />
            <p className="flex justify-between font-display text-xl">Total <span className="text-gold">${Number(open.total).toFixed(2)}</span></p>
            {open.notes && <p className="mt-3 text-sm text-muted-foreground">Notes: {open.notes}</p>}
            <div className="mt-6 text-right">
              <button onClick={() => setOpen(null)} className="rounded-full bg-gold px-4 py-2 text-xs uppercase tracking-widest text-primary-foreground">Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- Analytics ---------- */
function AnalyticsView() {
  const [bookings, setBookings] = useState<any[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [offline, setOffline] = useState<any[]>([]);
  const [monthOffset, setMonthOffset] = useState(0); // 0 = current
  const [source, setSource] = useState<"total" | "online" | "offline">("total");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [b, s, o] = await Promise.all([
        supabase.from("bookings").select("*"),
        supabase.from("services").select("*"),
        supabase.from("offline_sales").select("*"),
      ]);
      setBookings(b.data ?? []);
      setServices((s.data as Service[]) ?? []);
      setOffline(o.data ?? []);
      setLoading(false);
    })();
  }, []);

  const target = useMemo(() => {
    const d = new Date();
    d.setDate(1);
    d.setMonth(d.getMonth() + monthOffset);
    return d;
  }, [monthOffset]);

  const monthLabel = target.toLocaleString(undefined, { month: "long", year: "numeric" });

  const inMonth = (iso: string) => {
    const d = new Date(iso);
    return d.getMonth() === target.getMonth() && d.getFullYear() === target.getFullYear();
  };

  const monthly = bookings.filter((b) => inMonth(b.created_at));
  const monthlyOffline = offline.filter((o) => inMonth(o.sold_at));
  const useOnline = source !== "offline";
  const useOffline = source !== "online";

  const byCategory = useMemo(() => {
    const map = new Map<string, number>();
    if (useOnline) {
      for (const b of monthly) {
        for (const it of (b.items as any[]) || []) {
          const cat = it.category || services.find((s) => s.id === it.id)?.category || "Other";
          map.set(cat, (map.get(cat) || 0) + Number(it.price) * Number(it.qty || 1));
        }
      }
    }
    if (useOffline) {
      for (const o of monthlyOffline) {
        const cat = o.category || "Offline";
        map.set(cat, (map.get(cat) || 0) + Number(o.amount));
      }
    }
    return Array.from(map.entries()).map(([name, value]) => ({ name, value }));
  }, [monthly, monthlyOffline, services, useOnline, useOffline]);

  const last12 = useMemo(() => {
    const arr: { month: string; revenue: number; orders: number }[] = [];
    for (let i = 11; i >= 0; i--) {
      const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i);
      const list = bookings.filter((b) => {
        const x = new Date(b.created_at);
        return x.getMonth() === d.getMonth() && x.getFullYear() === d.getFullYear();
      });
      const off = offline.filter((o) => {
        const x = new Date(o.sold_at);
        return x.getMonth() === d.getMonth() && x.getFullYear() === d.getFullYear();
      });
      const onlineRev = useOnline ? list.reduce((s, b) => s + Number(b.total), 0) : 0;
      const offlineRev = useOffline ? off.reduce((s, o) => s + Number(o.amount), 0) : 0;
      const ordersCount = (useOnline ? list.length : 0) + (useOffline ? off.length : 0);
      arr.push({ month: d.toLocaleString(undefined, { month: "short" }), revenue: onlineRev + offlineRev, orders: ordersCount });
    }
    return arr;
  }, [bookings, offline, useOnline, useOffline]);

  const monthRevenue = (useOnline ? monthly.reduce((s, b) => s + Number(b.total), 0) : 0)
    + (useOffline ? monthlyOffline.reduce((s, o) => s + Number(o.amount), 0) : 0);
  const monthOrders = (useOnline ? monthly.length : 0) + (useOffline ? monthlyOffline.length : 0);
  const colors = ["#c9a14a", "#10b981", "#3b82f6", "#f43f5e", "#8b5cf6", "#f59e0b", "#06b6d4", "#ec4899"];

  if (loading) return <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-gold" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-2xl">Analytics</h2>
        <div className="flex items-center gap-2">
          <button onClick={() => setMonthOffset(monthOffset - 1)} className="rounded-full border border-border p-2"><ChevronLeft className="h-4 w-4" /></button>
          <p className="font-medium min-w-40 text-center">{monthLabel}</p>
          <button onClick={() => setMonthOffset(Math.min(0, monthOffset + 1))} disabled={monthOffset >= 0} className="rounded-full border border-border p-2 disabled:opacity-40"><ChevronRight className="h-4 w-4" /></button>
        </div>
      </div>

      <div className="inline-flex rounded-full border border-border p-1 bg-card">
        {(["total", "online", "offline"] as const).map((s) => (
          <button key={s} onClick={() => setSource(s)} className={`px-4 py-1.5 text-xs uppercase tracking-widest rounded-full transition ${source === s ? "bg-gold text-primary-foreground" : "text-foreground/70 hover:text-foreground"}`}>
            {s === "total" ? "Total" : s === "online" ? "Online Sales" : "Offline Sales"}
          </button>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <div className="glass rounded-xl p-5"><p className="text-xs uppercase tracking-widest text-muted-foreground">Month Revenue</p><p className="mt-2 font-display text-3xl text-gold">${monthRevenue.toFixed(2)}</p></div>
        <div className="glass rounded-xl p-5"><p className="text-xs uppercase tracking-widest text-muted-foreground">Month Orders</p><p className="mt-2 font-display text-3xl">{monthOrders}</p></div>
        <div className="glass rounded-xl p-5"><p className="text-xs uppercase tracking-widest text-muted-foreground">Avg. Order</p><p className="mt-2 font-display text-3xl">${monthOrders ? (monthRevenue / monthOrders).toFixed(2) : "0.00"}</p></div>
      </div>


      <div className="glass rounded-xl p-5">
        <h3 className="font-display text-xl mb-4">Revenue by Service Category — {monthLabel}</h3>
        {byCategory.length === 0 ? (
          <p className="text-sm text-muted-foreground py-10 text-center">No bookings this month.</p>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={byCategory}>
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <RTooltip />
                <Bar dataKey="value" fill="#c9a14a" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={byCategory} dataKey="value" nameKey="name" outerRadius={90} label>
                  {byCategory.map((_, i) => <Cell key={i} fill={colors[i % colors.length]} />)}
                </Pie>
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="glass rounded-xl p-5">
        <h3 className="font-display text-xl mb-4">Last 12 Months</h3>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={last12}>
            <XAxis dataKey="month" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 11 }} />
            <RTooltip />
            <Bar dataKey="revenue" fill="#c9a14a" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

/* ---------- Announcements ---------- */
interface Announcement { id: string; title: string; message: string; type: string; active: boolean; expires_at: string | null; created_at: string; }
function AnnouncementsManager() {
  const [items, setItems] = useState<Announcement[]>([]);
  const [form, setForm] = useState({ title: "", message: "", type: "sale", days: 7 });
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("announcements").select("*").order("created_at", { ascending: false });
    setItems((data as Announcement[]) ?? []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const push = async () => {
    if (!form.title || !form.message) return toast.error("Title and message required");
    const expires = new Date(); expires.setDate(expires.getDate() + Number(form.days || 7));
    const { error } = await supabase.from("announcements").insert({
      title: form.title, message: form.message, type: form.type, expires_at: expires.toISOString(),
    });
    if (error) return toast.error(error.message);
    toast.success("Announcement pushed to homepage");
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(form.title, { body: form.message });
    } else if ("Notification" in window && Notification.permission !== "denied") {
      Notification.requestPermission();
    }
    setForm({ title: "", message: "", type: "sale", days: 7 });
    load();
  };

  const toggle = async (id: string, active: boolean) => {
    await supabase.from("announcements").update({ active: !active }).eq("id", id);
    load();
  };
  const remove = async (id: string) => {
    if (!confirm("Delete this announcement?")) return;
    await supabase.from("announcements").delete().eq("id", id);
    load();
  };

  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl">Announcements & Sales</h2>

      <div className="glass rounded-xl p-5 space-y-3">
        <h3 className="font-display text-lg flex items-center gap-2"><Bell className="h-4 w-4 text-gold" /> Push New Banner</h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <Input label="Title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} placeholder="Summer Sale" />
          <div>
            <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Type</label>
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2.5">
              <option value="sale">Sale</option>
              <option value="discount">Discount</option>
              <option value="info">Info</option>
            </select>
          </div>
        </div>
        <Input label="Message" value={form.message} onChange={(v) => setForm({ ...form, message: v })} placeholder="20% off all watch repairs through July 31st" />
        <Input label="Show for (days)" type="number" value={String(form.days)} onChange={(v) => setForm({ ...form, days: Number(v) })} />
        <button onClick={push} className="inline-flex items-center gap-2 rounded-full bg-gold px-5 py-2.5 text-xs uppercase tracking-widest text-primary-foreground">
          <Megaphone className="h-4 w-4" /> Push to Homepage
        </button>
      </div>

      {loading ? (
        <div className="grid place-items-center py-10"><Loader2 className="h-5 w-5 animate-spin text-gold" /></div>
      ) : (
        <div className="space-y-2">
          {items.map((a) => (
            <div key={a.id} className="glass rounded-xl p-4 flex items-center gap-3">
              <span className={`shrink-0 inline-block h-2 w-2 rounded-full ${a.active ? "bg-emerald-500" : "bg-muted-foreground"}`} />
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{a.title} <span className="text-xs text-muted-foreground uppercase ml-2">{a.type}</span></p>
                <p className="text-sm text-muted-foreground truncate">{a.message}</p>
                {a.expires_at && <p className="text-xs text-muted-foreground">Expires {new Date(a.expires_at).toLocaleDateString()}</p>}
              </div>
              <button onClick={() => toggle(a.id, a.active)} className="text-xs rounded-full border border-border px-3 py-1.5">{a.active ? "Deactivate" : "Activate"}</button>
              <button onClick={() => remove(a.id)} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg"><Trash2 className="h-4 w-4" /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------- Settings ---------- */
function SettingsView() {
  const { user, refreshRole } = useAuth();
  const [profile, setProfile] = useState({ full_name: "", phone: "", otp_method: "email" });
  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const [payment, setPayment] = useState({ provider: "stripe", account_email: "", stripe_account_id: "", bank_info: "" });

  useEffect(() => {
    if (!user) return;
    setEmail(user.email || "");
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle().then(({ data }) => {
      if (data) setProfile({ full_name: data.full_name || "", phone: data.phone || "", otp_method: data.otp_method || "email" });
    });
    supabase.from("payment_settings").select("*").eq("id", 1).maybeSingle().then(({ data }) => {
      if (data) setPayment({
        provider: data.provider || "stripe",
        account_email: data.account_email || "",
        stripe_account_id: data.stripe_account_id || "",
        bank_info: typeof data.bank_info === "string" ? data.bank_info : JSON.stringify(data.bank_info || {}, null, 2),
      });
    });
  }, [user]);

  const saveProfile = async () => {
    if (!user) return;
    const { error } = await supabase.from("profiles").upsert({ id: user.id, ...profile, email: user.email });
    if (error) return toast.error(error.message);
    toast.success("Profile saved");
    refreshRole();
  };
  const saveEmail = async () => {
    const { error } = await supabase.auth.updateUser({ email });
    if (error) return toast.error(error.message);
    toast.success("Confirmation sent to your new email");
  };
  const savePwd = async () => {
    if (pwd.length < 8) return toast.error("Password must be 8+ chars");
    const { error } = await supabase.auth.updateUser({ password: pwd });
    if (error) return toast.error(error.message);
    toast.success("Password updated");
    setPwd("");
  };
  const savePayment = async () => {
    let bank_info: any = {};
    try { bank_info = payment.bank_info ? JSON.parse(payment.bank_info) : {}; } catch { return toast.error("Bank info must be valid JSON"); }
    const { error } = await supabase.from("payment_settings").update({
      provider: payment.provider, account_email: payment.account_email,
      stripe_account_id: payment.stripe_account_id, bank_info,
    }).eq("id", 1);
    if (error) return toast.error(error.message);
    toast.success("Payment settings saved");
  };

  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl">Settings</h2>

      <Card title="Account Profile" icon={<Mail className="h-4 w-4 text-gold" />}>
        <Input label="Full Name" value={profile.full_name} onChange={(v) => setProfile({ ...profile, full_name: v })} />
        <Input label="Phone" value={profile.phone} onChange={(v) => setProfile({ ...profile, phone: v })} placeholder="+1 555 123 4567" />
        <div>
          <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">OTP Delivery</label>
          <select value={profile.otp_method} onChange={(e) => setProfile({ ...profile, otp_method: e.target.value })} className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2.5">
            <option value="email">Email (recommended)</option>
            <option value="sms">SMS (requires SMS provider)</option>
          </select>
        </div>
        <SaveBtn onClick={saveProfile} />
      </Card>

      <Card title="Change Email" icon={<Mail className="h-4 w-4 text-gold" />}>
        <Input label="New Email" type="email" value={email} onChange={setEmail} />
        <SaveBtn onClick={saveEmail} label="Update Email" />
      </Card>

      <Card title="Change Password" icon={<Lock className="h-4 w-4 text-gold" />}>
        <Input label="New Password" type="password" value={pwd} onChange={setPwd} />
        <SaveBtn onClick={savePwd} label="Update Password" />
      </Card>

      <Card title="Payment Payout Settings" icon={<CreditCard className="h-4 w-4 text-gold" />}>
        <p className="text-sm text-muted-foreground">Where customer payments are deposited. For real Stripe payouts, you can also enable our Stripe payments integration in a follow-up step.</p>
        <Input label="Provider" value={payment.provider} onChange={(v) => setPayment({ ...payment, provider: v })} />
        <Input label="Payout Account Email" value={payment.account_email} onChange={(v) => setPayment({ ...payment, account_email: v })} />
        <Input label="Stripe Connected Account ID" value={payment.stripe_account_id} onChange={(v) => setPayment({ ...payment, stripe_account_id: v })} placeholder="acct_..." />
        <div>
          <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Bank Info (JSON)</label>
          <textarea value={payment.bank_info} onChange={(e) => setPayment({ ...payment, bank_info: e.target.value })} rows={5} className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2.5 font-mono text-xs" placeholder='{"bank":"Chase","account_last4":"1234"}' />
        </div>
        <SaveBtn onClick={savePayment} />
      </Card>
    </div>
  );
}

/* ---------- shared bits ---------- */
function Input({ label, value, onChange, type = "text", placeholder }: { label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string }) {
  return (
    <div>
      <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{label}</label>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2.5 focus:border-gold focus:outline-none" />
    </div>
  );
}
function Card({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="glass rounded-xl p-5 space-y-3">
      <h3 className="font-display text-lg flex items-center gap-2">{icon} {title}</h3>
      {children}
    </div>
  );
}
function SaveBtn({ onClick, label = "Save" }: { onClick: () => void; label?: string }) {
  return (
    <button onClick={onClick} className="inline-flex items-center gap-2 rounded-full bg-gold px-5 py-2.5 text-xs uppercase tracking-widest text-primary-foreground">
      <Save className="h-4 w-4" /> {label}
    </button>
  );
}

/* ---------- Users (manual add + list) ---------- */
function UsersManager() {
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ full_name: "", email: "", phone: "" });
  const [query, setQuery] = useState("");


  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("profiles").select("*").order("created_at", { ascending: false });
    setList(data ?? []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const add = async () => {
    if (!form.full_name) return toast.error("Name required");
    const { error } = await supabase.from("profiles").insert({
      id: crypto.randomUUID(),
      full_name: form.full_name,
      email: form.email || null,
      phone: form.phone || null,
    });
    if (error) return toast.error(error.message);
    toast.success("User added");
    setForm({ full_name: "", email: "", phone: "" });
    load();
  };

  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl">Users</h2>

      <div className="glass rounded-xl p-5 space-y-3">
        <h3 className="font-display text-lg flex items-center gap-2"><Plus className="h-4 w-4 text-gold" /> Add User Manually</h3>
        <div className="grid sm:grid-cols-3 gap-3">
          <Input label="Full Name *" value={form.full_name} onChange={(v) => setForm({ ...form, full_name: v })} />
          <Input label="Email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} placeholder="optional" />
          <Input label="Phone" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} placeholder="optional" />
        </div>
        <SaveBtn onClick={add} label="Add User" />
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search returning customers by name, email or phone…"
          className="w-full rounded-full border border-border bg-card pl-10 pr-4 py-2.5 text-sm focus:border-gold focus:outline-none"
        />
      </div>

      {loading ? (
        <div className="grid place-items-center py-10"><Loader2 className="h-5 w-5 animate-spin text-gold" /></div>
      ) : (
        <div className="glass rounded-xl divide-y divide-border overflow-hidden">
          {(() => {
            const q = query.trim().toLowerCase();
            const filtered = q
              ? list.filter((u) => `${u.full_name || ""} ${u.email || ""} ${u.phone || ""}`.toLowerCase().includes(q))
              : list;
            if (filtered.length === 0) return <p className="p-8 text-center text-muted-foreground">{q ? "No users match your search." : "No users yet."}</p>;
            return filtered.map((u) => (
              <div key={u.id} className="p-4 flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-gold/15 text-gold grid place-items-center text-xs font-bold">
                  {(u.full_name || u.email || "?").slice(0, 1).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{u.full_name || "Unnamed"}</p>
                  <p className="text-xs text-muted-foreground truncate">{u.email || "—"}{u.phone ? ` · ${u.phone}` : ""}</p>
                </div>
                <button
                  onClick={() => setForm({ full_name: u.full_name || "", email: u.email || "", phone: u.phone || "" })}
                  className="text-[10px] uppercase tracking-widest rounded-full border border-border px-3 py-1.5 hover:bg-foreground/5"
                  title="Pre-fill the form to add a new repair/sale for this returning customer"
                >
                  Add Repair
                </button>
                <p className="text-xs text-muted-foreground hidden sm:block">{new Date(u.created_at).toLocaleDateString()}</p>
              </div>
            ));
          })()}
        </div>
      )}
    </div>
  );
}

/* ---------- Offline Sales ---------- */
function OfflineSalesManager() {
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    customer_name: "", customer_email: "", customer_phone: "",
    category: "", amount: "", description: "",
    sold_at: new Date().toISOString().slice(0, 10), notes: "",
  });

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("offline_sales").select("*").order("sold_at", { ascending: false });
    setList(data ?? []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  // Pack optional contact info into the existing `notes` column so nothing is mandatory.
  const packNotes = (f: typeof form) => {
    const parts: string[] = [];
    if (f.customer_name) parts.push(`Name: ${f.customer_name}`);
    if (f.customer_email) parts.push(`Email: ${f.customer_email}`);
    if (f.customer_phone) parts.push(`Phone: ${f.customer_phone}`);
    if (f.notes) parts.push(f.notes);
    return parts.join(" · ") || null;
  };

  const add = async () => {
    const { error } = await supabase.from("offline_sales").insert({
      category: form.category || "Other",
      amount: Number(form.amount) || 0,
      description: form.description || null,
      notes: packNotes(form),
      sold_at: new Date(form.sold_at || new Date().toISOString()).toISOString(),
    });
    if (error) return toast.error(error.message);
    toast.success("Offline sale recorded");
    setForm({ customer_name: "", customer_email: "", customer_phone: "", category: "", amount: "", description: "", sold_at: new Date().toISOString().slice(0, 10), notes: "" });
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this sale?")) return;
    await supabase.from("offline_sales").delete().eq("id", id);
    load();
  };

  const total = list.reduce((s, o) => s + Number(o.amount || 0), 0);

  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl">Offline Sales</h2>
      <p className="text-sm text-muted-foreground">Record walk-in / in-store sales. All fields are optional.</p>

      <div className="glass rounded-xl p-4 sm:p-5 space-y-3">
        <h3 className="font-display text-lg flex items-center gap-2"><DollarSign className="h-4 w-4 text-gold" /> Add Offline Sale</h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <Input label="Customer Name (optional)" value={form.customer_name} onChange={(v) => setForm({ ...form, customer_name: v })} />
          <Input label="Email (optional)" type="email" value={form.customer_email} onChange={(v) => setForm({ ...form, customer_email: v })} />
          <Input label="Phone (optional)" value={form.customer_phone} onChange={(v) => setForm({ ...form, customer_phone: v })} />
          <div>
            <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Category (optional)</label>
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2.5">
              <option value="">—</option>
              {["Watch Repair", "Ring Repair", "Cleaning", "Engraving", "Stone & Setting", "Appraisal", "Replacement Parts", "Other"].map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <Input label="Amount $ (optional)" type="number" value={form.amount} onChange={(v) => setForm({ ...form, amount: v })} />
          <Input label="Sold On (optional)" type="date" value={form.sold_at} onChange={(v) => setForm({ ...form, sold_at: v })} />
        </div>
        <Input label="Description (optional)" value={form.description} onChange={(v) => setForm({ ...form, description: v })} />
        <Input label="Notes (optional)" value={form.notes} onChange={(v) => setForm({ ...form, notes: v })} />
        <SaveBtn onClick={add} label="Record Sale" />
      </div>

      <div className="glass rounded-xl p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <h3 className="font-display text-lg">Recent Sales</h3>
          <p className="font-display text-xl text-gold">${total.toFixed(2)} <span className="text-xs uppercase tracking-widest text-muted-foreground">total</span></p>
        </div>
        {loading ? (
          <div className="grid place-items-center py-10"><Loader2 className="h-5 w-5 animate-spin text-gold" /></div>
        ) : list.length === 0 ? (
          <p className="text-sm text-muted-foreground py-4">No offline sales recorded yet.</p>
        ) : (
          <div className="divide-y divide-border">
            {list.map((o) => (
              <div key={o.id} className="py-3 flex flex-wrap items-center gap-3">
                <span className="text-[10px] uppercase tracking-widest text-gold w-full sm:w-32 shrink-0">{o.category || "—"}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm truncate">{o.description || "—"}</p>
                  <p className="text-xs text-muted-foreground">{new Date(o.sold_at).toLocaleDateString()}{o.notes ? ` · ${o.notes}` : ""}</p>
                </div>
                <p className="font-display text-lg shrink-0">${Number(o.amount || 0).toFixed(2)}</p>
                <button onClick={() => remove(o.id)} className="p-2 rounded-lg text-destructive hover:bg-destructive/10"><Trash2 className="h-4 w-4" /></button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------- Manual Email Composer ---------- */
function ManualEmailComposer() {
  const [recipients, setRecipients] = useState<{ name: string; email: string; phone?: string; source: string }[]>([]);
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [query, setQuery] = useState("");

  useEffect(() => {
    (async () => {
      const [{ data: profs }, { data: bks }, { data: offs }] = await Promise.all([
        supabase.from("profiles").select("full_name,email,phone").order("created_at", { ascending: false }),
        supabase.from("bookings").select("customer_name,customer_email,customer_phone").order("created_at", { ascending: false }),
        supabase.from("offline_sales").select("notes").order("sold_at", { ascending: false }),
      ]);
      const list: { name: string; email: string; phone?: string; source: string }[] = [];
      (profs ?? []).forEach((p: any) => p.email && list.push({ name: p.full_name || "—", email: p.email, phone: p.phone, source: "User" }));
      (bks ?? []).forEach((b: any) => b.customer_email && list.push({ name: b.customer_name, email: b.customer_email, phone: b.customer_phone, source: "Online" }));
      (offs ?? []).forEach((o: any) => {
        const m = /Email:\s*([^\s·]+)/i.exec(o.notes || "");
        const n = /Name:\s*([^·]+)/i.exec(o.notes || "");
        if (m) list.push({ name: (n?.[1] || "Offline customer").trim(), email: m[1].trim(), source: "Offline" });
      });
      // Dedupe by email
      const seen = new Set<string>();
      setRecipients(list.filter((r) => (seen.has(r.email.toLowerCase()) ? false : (seen.add(r.email.toLowerCase()), true))));
    })();
  }, []);

  const filtered = query
    ? recipients.filter((r) => `${r.name} ${r.email} ${r.phone || ""}`.toLowerCase().includes(query.toLowerCase()))
    : recipients;

  const send = () => {
    if (!to) return toast.error("Recipient email required");
    const url = `mailto:${encodeURIComponent(to)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(url, "_blank");
    toast.success("Opened your email client");
  };

  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl">Send Email to a User</h2>
      <p className="text-sm text-muted-foreground">Compose a one-off email to any online or offline customer. Opens your email client pre-filled.</p>

      <div className="glass rounded-xl p-4 sm:p-5 space-y-3">
        <Input label="To" type="email" value={to} onChange={setTo} placeholder="customer@example.com" />
        <Input label="Subject" value={subject} onChange={setSubject} placeholder="An update from Quality Jewelry Repair" />
        <div>
          <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Message</label>
          <textarea rows={6} value={body} onChange={(e) => setBody(e.target.value)} className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2.5 focus:border-gold focus:outline-none" placeholder="Hi there,&#10;&#10;..." />
        </div>
        <button onClick={send} className="inline-flex items-center gap-2 rounded-full bg-gold px-5 py-2.5 text-xs uppercase tracking-widest text-primary-foreground">
          <Send className="h-4 w-4" /> Open Email Client
        </button>
      </div>

      <div className="glass rounded-xl p-4 sm:p-5">
        <h3 className="font-display text-lg mb-3">Pick a recipient</h3>
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by name, email, phone…" className="w-full rounded-full border border-border bg-card pl-10 pr-4 py-2.5 text-sm focus:border-gold focus:outline-none" />
        </div>
        {filtered.length === 0 ? (
          <p className="text-sm text-muted-foreground py-4 text-center">No matching contacts.</p>
        ) : (
          <div className="divide-y divide-border max-h-80 overflow-y-auto">
            {filtered.slice(0, 50).map((r, i) => (
              <button key={i} onClick={() => setTo(r.email)} className="w-full text-left p-3 hover:bg-foreground/5 flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{r.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{r.email}{r.phone ? ` · ${r.phone}` : ""}</p>
                </div>
                <span className="text-[10px] uppercase tracking-widest text-gold shrink-0">{r.source}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------- Push to Users (broadcast) ---------- */
function PushToUsersManager() {
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ title: "", message: "" });
  const [sending, setSending] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("user_notifications").select("*").order("created_at", { ascending: false });
    setList(data ?? []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const send = async () => {
    if (!form.title || !form.message) return toast.error("Title and message required");
    setSending(true);
    const { error } = await supabase.from("user_notifications").insert(form);
    setSending(false);
    if (error) return toast.error(error.message);
    if ("Notification" in window) {
      if (Notification.permission === "default") await Notification.requestPermission();
      if (Notification.permission === "granted") new Notification(form.title, { body: form.message });
    }
    toast.success("Notification sent to all users");
    setForm({ title: "", message: "" });
    load();
  };

  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl">Push Notification to All Users</h2>
      <p className="text-sm text-muted-foreground">Broadcast a message to every visitor. They'll see a browser notification (if permitted) and an in-app banner.</p>

      <div className="glass rounded-xl p-5 space-y-3">
        <Input label="Title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} placeholder="Important update" />
        <div>
          <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Message</label>
          <textarea rows={4} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2.5 focus:border-gold focus:outline-none" />
        </div>
        <button disabled={sending} onClick={send} className="inline-flex items-center gap-2 rounded-full bg-gold px-5 py-2.5 text-xs uppercase tracking-widest text-primary-foreground disabled:opacity-60">
          {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} Push to Users
        </button>
      </div>

      {loading ? (
        <div className="grid place-items-center py-10"><Loader2 className="h-5 w-5 animate-spin text-gold" /></div>
      ) : (
        <div className="space-y-2">
          {list.length === 0 ? (
            <p className="glass rounded-xl p-8 text-center text-muted-foreground">No notifications sent yet.</p>
          ) : list.map((n) => (
            <div key={n.id} className="glass rounded-xl p-4">
              <div className="flex items-start justify-between gap-3">
                <p className="font-medium">{n.title}</p>
                <p className="text-xs text-muted-foreground shrink-0">{new Date(n.created_at).toLocaleString()}</p>
              </div>
              <p className="text-sm text-muted-foreground mt-1">{n.message}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

