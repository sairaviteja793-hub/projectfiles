import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Package, Truck, Wrench, Mail, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/how-it-works")({
  head: () => ({
    meta: [
      { title: "How It Works — Quality Jewelry Repair" },
      { name: "description", content: "Our four-step mail-in jewelry & watch repair process: order online, mail in, master repair, returned sparkling." },
    ],
  }),
  component: HowItWorks,
});

const steps = [
  { icon: Package, t: "Order Online", d: "Choose your repair service from our transparent menu and complete secure checkout. You'll receive an instant confirmation and a prepaid, fully insured UPS shipping label." },
  { icon: Truck, t: "Mail It In", d: "Place your item in any padded box, attach the label, and drop it at any UPS location. Every shipment is tracked and insured up to $25,000." },
  { icon: Wrench, t: "Master Repair", d: "Our certified jewelers and watchmakers inspect, restore, and rigorously quality-check your piece. We photograph every step for your peace of mind." },
  { icon: Mail, t: "Returned Sparkling", d: "Your piece is professionally cleaned, packaged in a luxury box, and returned via insured express shipping in 7–14 business days." },
];

export default function HowItWorks() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-20">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
        <p className="text-xs uppercase tracking-[0.3em] text-gold">Process</p>
        <h1 className="mt-4 font-display text-5xl md:text-7xl">How It Works</h1>
        <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
          A meticulous four-step process designed to feel effortless, transparent and entirely safe — from the moment you order to the moment your piece returns to your hand.
        </p>
      </motion.div>

      <div className="mt-20 space-y-12">
        {steps.map((s, i) => (
          <motion.div
            key={s.t}
            initial={{ opacity: 0, x: i % 2 ? 40 : -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.7, delay: 0.05 * i }}
            className="grid md:grid-cols-[140px_1fr] gap-8 items-start glass rounded-2xl p-8 hover-lift"
          >
            <div className="flex flex-col items-center md:items-start gap-3">
              <div className="flex h-16 w-16 items-center justify-center rounded-full border border-gold/30 bg-card">
                <s.icon className="h-6 w-6 text-gold" />
              </div>
              <span className="font-display text-3xl text-gold">0{i + 1}</span>
            </div>
            <div>
              <h2 className="font-display text-3xl">{s.t}</h2>
              <p className="mt-3 text-muted-foreground leading-relaxed">{s.d}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-20 text-center">
        <Link to="/repair" className="inline-flex items-center gap-2 rounded-full bg-gold px-10 py-4 text-sm font-medium uppercase tracking-[0.2em] text-primary-foreground shadow-gold hover:scale-105 transition-transform"
        >
          Begin Your Repair <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
