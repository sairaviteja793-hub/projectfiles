import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Package, ShoppingBag, Settings, Loader2, LogOut, Home, Mail, User as UserIcon, Lock, Save, Sparkles, Clock, CheckCircle2, Truck, XCircle, Wrench,
  Heart, ShoppingCart, Plus, Minus, Trash2, Star, ArrowRight, Search,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { ThemeToggle } from "@/components/ThemeToggle";
import { SERVICES, CATEGORIES, CATEGORY_IMAGE, type CategoryId } from "@/lib/services-catalog";
import {
  readCart, addToCart, updateCartQty, removeFromCart, clearCart, onCartChange,
  readWish, toggleWish, removeFromWish, onWishChange, syncWishFromDb,
} from "@/lib/cart-store";

export const Route = createFileRoute("/account")({
  head: () => ({
    meta: [
      { title: "My Account — Quality Jewelry Repair" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: AccountPage,
});

type Tab = "orders" | "services" | "cart" | "wishlist" | "settings";
const TAB_IDS: Tab[] = ["orders", "services", "cart", "wishlist", "settings"];

const STATUS_META: Record<string, { label: string; icon: any; color: string }> = {
  pending: { label: "Pending", icon: Clock, color: "text-amber-500 bg-amber-500/10" },
  received: { label: "Received", icon: Package, color: "text-blue-500 bg-blue-500/10" },
  in_progress: { label: "In Progress", icon: Wrench, color: "text-indigo-500 bg-indigo-500/10" },
  under_repair: { label: "Under Repair", icon: Wrench, color: "text-indigo-500 bg-indigo-500/10" },
  repair_completed: { label: "Repair Completed", icon: CheckCircle2, color: "text-emerald-500 bg-emerald-500/10" },
  out_for_delivery: { label: "Out for Delivery", icon: Truck, color: "text-cyan-500 bg-cyan-500/10" },
  delivered: { label: "Delivered", icon: CheckCircle2, color: "text-emerald-600 bg-emerald-600/10" },
  cancelled: { label: "Cancelled", icon: XCircle, color: "text-destructive bg-destructive/10" },
};

function AccountPage() {
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const readHashTab = (): Tab => {
    if (typeof window === "undefined") return "orders";
    const h = window.location.hash.replace("#", "");
    return TAB_IDS.includes(h as Tab) ? (h as Tab) : "orders";
  };
  const [tab, setTab] = useState<Tab>(readHashTab);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/login", search: { redirect: "/account" } as never });
  }, [loading, user]);

  useEffect(() => {
    const onHash = () => setTab(readHashTab());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const selectTab = (t: Tab) => {
    setTab(t);
    if (typeof window !== "undefined") window.history.replaceState(null, "", `#${t}`);
  };

  if (loading) return <div className="grid min-h-[60vh] place-items-center"><Loader2 className="h-6 w-6 animate-spin text-gold" /></div>;
  if (!user) return null;

  const TABS: { id: Tab; label: string; icon: any }[] = [
    { id: "orders", label: "My Orders", icon: ShoppingBag },
    { id: "services", label: "Services", icon: Sparkles },
    { id: "cart", label: "Cart", icon: ShoppingCart },
    { id: "wishlist", label: "Wishlist", icon: Heart },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="mx-auto max-w-[88rem] px-4 sm:px-6 lg:px-10 py-6 sm:py-10">
      <header className="flex flex-wrap items-center justify-between gap-3 mb-6 sm:mb-8">
        <div className="flex items-center gap-3 min-w-0">
          <div className="inline-flex h-11 w-11 sm:h-12 sm:w-12 items-center justify-center rounded-full border border-gold/40 shrink-0">
            <UserIcon className="h-5 w-5 text-gold" />
          </div>
          <div className="min-w-0">
            <h1 className="font-display text-xl sm:text-3xl truncate">My Account</h1>
            <p className="text-[10px] sm:text-xs uppercase tracking-widest text-muted-foreground truncate">{user.email}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Link to="/" className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-2 text-xs uppercase tracking-widest hover:bg-foreground/5"><Home className="h-3.5 w-3.5" /> <span className="hidden sm:inline">Home</span></Link>
          <button onClick={signOut} className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-2 text-xs uppercase tracking-widest hover:bg-destructive/10 hover:text-destructive"><LogOut className="h-3.5 w-3.5" /> <span className="hidden sm:inline">Sign Out</span></button>
        </div>
      </header>

      <div className="flex flex-col md:flex-row gap-6">
        <aside className="hidden md:block w-56 shrink-0">
          <nav className="glass rounded-xl p-2 sticky top-24 space-y-1">
            {TABS.map((t) => (
              <button key={t.id} onClick={() => selectTab(t.id)} className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${tab === t.id ? "bg-gold text-primary-foreground" : "text-foreground/70 hover:bg-foreground/5"}`}>
                <t.icon className="h-4 w-4" /> {t.label}
              </button>
            ))}
          </nav>
        </aside>

        <div className="md:hidden -mx-4 px-4 overflow-x-auto pb-3 flex gap-2">
          {TABS.map((t) => (
            <button key={t.id} onClick={() => selectTab(t.id)} className={`shrink-0 inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs ${tab === t.id ? "bg-gold text-primary-foreground border-gold" : "border-border text-foreground/70"}`}>
              <t.icon className="h-3.5 w-3.5" /> {t.label}
            </button>
          ))}
        </div>

        <section className="flex-1 min-w-0">
          <motion.div key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }}>
            {tab === "orders" && <MyOrders />}
            {tab === "services" && <ServicesCatalog />}
            {tab === "cart" && <CartView />}
            {tab === "wishlist" && <WishlistView selectTab={selectTab} />}
            {tab === "settings" && <MySettings />}
          </motion.div>
        </section>
      </div>
    </div>
  );
}

/* ---------- My Orders ---------- */
function MyOrders() {
  const { user } = useAuth();
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState<any | null>(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      setLoading(true);
      const { data } = await supabase
        .from("bookings")
        .select("*")
        .or(`user_id.eq.${user.id},customer_email.eq.${user.email}`)
        .order("created_at", { ascending: false });
      setList(data ?? []);
      setLoading(false);
    })();
  }, [user]);

  if (loading) return <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-gold" /></div>;

  if (list.length === 0) {
    return (
      <div className="glass rounded-xl p-8 sm:p-12 text-center">
        <ShoppingBag className="h-10 w-10 text-gold mx-auto mb-3" />
        <h2 className="font-display text-2xl mb-2">No orders yet</h2>
        <p className="text-sm text-muted-foreground mb-6">Browse services and place your first order.</p>
        <Link to="/account" hash="services" className="inline-flex items-center gap-2 rounded-full bg-gold px-5 py-2.5 text-xs uppercase tracking-widest text-primary-foreground">
          Browse Services
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="font-display text-2xl">My Orders</h2>
      <div className="space-y-3">
        {list.map((b) => {
          const meta = STATUS_META[b.status] ?? STATUS_META.pending;
          const Icon = meta.icon;
          return (
            <div key={b.id} className="glass rounded-xl p-4 space-y-3">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Order #{b.id.slice(0, 8)}</p>
                  <p className="text-xs text-muted-foreground">{new Date(b.created_at).toLocaleString()}</p>
                </div>
                <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs ${meta.color}`}>
                  <Icon className="h-3.5 w-3.5" /> {meta.label}
                </span>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="text-sm text-muted-foreground">{(b.items as any[]).length} item{(b.items as any[]).length === 1 ? "" : "s"}</p>
                <p className="font-display text-xl text-gold">${Number(b.total).toFixed(2)}</p>
              </div>
              <button onClick={() => setOpen(b)} className="text-xs uppercase tracking-widest text-gold hover:underline">View details →</button>
            </div>
          );
        })}
      </div>

      {open && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 backdrop-blur-sm p-4" onClick={() => setOpen(null)}>
          <div className="glass-strong rounded-2xl p-5 sm:p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-display text-2xl">Order #{open.id.slice(0, 8)}</h3>
            <p className="text-xs text-muted-foreground">{new Date(open.created_at).toLocaleString()}</p>
            <hr className="my-4 border-border" />
            <ul className="space-y-2">
              {(open.items as any[]).map((it: any, i: number) => (
                <li key={i} className="flex justify-between gap-3 text-sm">
                  <span className="min-w-0 truncate">{it.title} <span className="text-muted-foreground">× {it.qty || 1}</span></span>
                  <span className="shrink-0">${Number(it.price).toFixed(2)}</span>
                </li>
              ))}
            </ul>
            <hr className="my-4 border-border" />
            <p className="flex justify-between font-display text-xl">Total <span className="text-gold">${Number(open.total).toFixed(2)}</span></p>
            {open.customer_address && <p className="text-xs text-muted-foreground mt-3">Ship to: {open.customer_address}</p>}
            {open.notes && <p className="mt-2 text-sm text-muted-foreground">Notes: {open.notes}</p>}
            <div className="mt-6 text-right">
              <button onClick={() => setOpen(null)} className="rounded-full bg-gold px-4 py-2 text-xs uppercase tracking-widest text-primary-foreground">Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- Services catalog (ecommerce-style) ---------- */
function ServicesCatalog() {
  const { user } = useAuth();
  const [filter, setFilter] = useState<CategoryId>("all");
  const [q, setQ] = useState("");
  const [wish, setWish] = useState(() => readWish(user?.id));

  useEffect(() => {
    if (!user) return;
    setWish(readWish(user.id));
    syncWishFromDb(user.id).then((items) => setWish(items));
    return onWishChange(() => setWish(readWish(user.id)));
  }, [user?.id]);

  const visible = useMemo(() => {
    let list = SERVICES;
    if (filter === "popular") list = list.filter((s) => s.popular);
    else if (filter !== "all") list = list.filter((s) => s.category === filter);
    if (q) {
      const lo = q.toLowerCase();
      list = list.filter((s) => `${s.name} ${s.desc} ${s.category}`.toLowerCase().includes(lo));
    }
    return list;
  }, [filter, q]);

  if (!user) return null;
  const isWished = (id: string) => wish.some((w) => w.id === id);

  const onAdd = (id: string) => {
    const s = SERVICES.find((x) => x.id === id)!;
    addToCart(user.id, { id: s.id, title: s.name, category: s.category, price: s.price, image: s.image });
    toast.success(`${s.name} added to cart`);
  };
  const onWish = async (id: string) => {
    const s = SERVICES.find((x) => x.id === id)!;
    const added = await toggleWish(user.id, { id: s.id, title: s.name, category: s.category, price: s.price, image: s.image });
    toast.success(added ? "Added to wishlist" : "Removed from wishlist");
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-2xl">Available Services</h2>
        <Link to="/account" hash="cart" className="inline-flex items-center gap-2 rounded-full bg-gold px-4 py-2 text-xs uppercase tracking-widest text-primary-foreground">
          <ShoppingCart className="h-3.5 w-3.5" /> View Cart
        </Link>
      </div>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search services…" maxLength={100} className="w-full rounded-full border border-border bg-card pl-10 pr-4 py-2.5 text-sm focus:border-gold focus:outline-none" />
      </div>
      <div className="-mx-4 px-4 overflow-x-auto flex gap-2 pb-2">
        {CATEGORIES.map((c) => (
          <button key={c.id} onClick={() => setFilter(c.id)} className={`shrink-0 inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs ${filter === c.id ? "bg-gold text-primary-foreground border-gold" : "border-border text-foreground/70 hover:border-gold"}`}>
            <c.icon className="h-3.5 w-3.5" /> {c.label}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {visible.map((s) => (
          <div key={s.id} className="rounded-2xl border border-border bg-card overflow-hidden hover-lift flex flex-col">
            <div className="relative aspect-[4/3] overflow-hidden bg-muted">
              <img src={s.image || CATEGORY_IMAGE[s.category]} alt={s.name} loading="lazy" className="h-full w-full object-cover" />
              {s.popular && (
                <span className="absolute top-3 left-3 inline-flex items-center gap-1 rounded-full bg-gold/95 px-2.5 py-1 text-[10px] uppercase tracking-[0.2em] text-primary-foreground">
                  <Star className="h-3 w-3" /> Popular
                </span>
              )}
              <button onClick={() => onWish(s.id)} aria-label="Toggle wishlist" className={`absolute top-3 right-3 h-9 w-9 rounded-full grid place-items-center backdrop-blur transition-colors ${isWished(s.id) ? "bg-destructive text-destructive-foreground" : "bg-background/80 text-foreground/70 hover:text-destructive"}`}>
                <Heart className={`h-4 w-4 ${isWished(s.id) ? "fill-current" : ""}`} />
              </button>
            </div>
            <div className="p-4 flex-1 flex flex-col">
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-display text-base leading-tight">{s.name}</h3>
                <div className="font-display text-lg text-gold shrink-0">${s.price.toFixed(2)}</div>
              </div>
              <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{s.desc}</p>
              <button onClick={() => onAdd(s.id)} className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-full bg-foreground/95 px-4 py-2 text-[11px] uppercase tracking-[0.2em] text-background hover:bg-gold transition-colors">
                <Plus className="h-3.5 w-3.5" /> Add to Cart
              </button>
            </div>
          </div>
        ))}
      </div>

      {visible.length === 0 && (
        <p className="text-center py-12 text-sm text-muted-foreground">No services match your search.</p>
      )}
    </div>
  );
}

/* ---------- Cart ---------- */
function CartView() {
  const { user } = useAuth();
  const [items, setItems] = useState(() => readCart(user?.id));
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) return;
    setItems(readCart(user.id));
    return onCartChange(() => setItems(readCart(user.id)));
  }, [user?.id]);

  if (!user) return null;
  const subtotal = items.reduce((n, i) => n + i.price * i.qty, 0);

  if (items.length === 0) {
    return (
      <div className="glass rounded-xl p-8 sm:p-12 text-center">
        <ShoppingCart className="h-10 w-10 text-gold mx-auto mb-3" />
        <h2 className="font-display text-2xl mb-2">Your cart is empty</h2>
        <p className="text-sm text-muted-foreground mb-6">Add services to get started.</p>
        <Link to="/account" hash="services" className="inline-flex items-center gap-2 rounded-full bg-gold px-5 py-2.5 text-xs uppercase tracking-widest text-primary-foreground">
          Browse Services
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="font-display text-2xl">Cart</h2>
      <div className="space-y-3">
        {items.map((it) => (
          <div key={it.id} className="glass rounded-xl p-3 flex items-center gap-3">
            <img src={it.image || CATEGORY_IMAGE[it.category]} alt={it.title} className="h-16 w-16 rounded-lg object-cover shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{it.title}</p>
              <p className="text-sm text-gold">${it.price.toFixed(2)}</p>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button onClick={() => updateCartQty(user.id, it.id, it.qty - 1)} className="h-7 w-7 grid place-items-center rounded-full border border-border hover:border-gold"><Minus className="h-3 w-3" /></button>
              <span className="w-6 text-center text-sm">{it.qty}</span>
              <button onClick={() => updateCartQty(user.id, it.id, it.qty + 1)} className="h-7 w-7 grid place-items-center rounded-full border border-border hover:border-gold"><Plus className="h-3 w-3" /></button>
              <button onClick={() => removeFromCart(user.id, it.id)} className="h-7 w-7 grid place-items-center rounded-full border border-border hover:border-destructive text-muted-foreground hover:text-destructive ml-1"><Trash2 className="h-3 w-3" /></button>
            </div>
          </div>
        ))}
      </div>
      <div className="glass rounded-xl p-5">
        <div className="flex justify-between font-display text-xl"><span>Total</span><span className="text-gold">${subtotal.toFixed(2)}</span></div>
        <p className="text-xs text-muted-foreground mt-1">Free insured shipping included.</p>
        <div className="mt-4 flex flex-wrap gap-2">
          <button onClick={() => navigate({ to: "/repair", hash: "details" } as never)} className="flex-1 inline-flex items-center justify-center gap-2 rounded-full bg-gold px-6 py-3 text-xs uppercase tracking-[0.2em] text-primary-foreground shadow-gold hover:scale-[1.02] transition-transform">
            Checkout <ArrowRight className="h-3.5 w-3.5" />
          </button>
          <button onClick={() => { clearCart(user.id); toast.success("Cart cleared"); }} className="rounded-full border border-border px-5 py-3 text-xs uppercase tracking-[0.2em] hover:border-destructive hover:text-destructive">
            Clear
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------- Wishlist ---------- */
function WishlistView({ selectTab }: { selectTab: (t: Tab) => void }) {
  const { user } = useAuth();
  const [items, setItems] = useState(() => readWish(user?.id));

  useEffect(() => {
    if (!user) return;
    setItems(readWish(user.id));
    syncWishFromDb(user.id).then((data) => setItems(data));
    return onWishChange(() => setItems(readWish(user.id)));
  }, [user?.id]);

  if (!user) return null;

  if (items.length === 0) {
    return (
      <div className="glass rounded-xl p-8 sm:p-12 text-center">
        <Heart className="h-10 w-10 text-gold mx-auto mb-3" />
        <h2 className="font-display text-2xl mb-2">Wishlist is empty</h2>
        <p className="text-sm text-muted-foreground mb-6">Tap the heart on any service to save it for later.</p>
        <Link to="/account" hash="services" className="inline-flex items-center gap-2 rounded-full bg-gold px-5 py-2.5 text-xs uppercase tracking-widest text-primary-foreground">
          Browse Services
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="font-display text-2xl">Wishlist</h2>
      <div className="grid sm:grid-cols-2 gap-3">
        {items.map((it) => (
          <div key={it.id} className="glass rounded-xl p-3 flex gap-3">
            <img src={it.image || CATEGORY_IMAGE[it.category]} alt={it.title} className="h-16 w-16 rounded-lg object-cover shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{it.title}</p>
              <p className="text-sm text-gold">${it.price.toFixed(2)}</p>
              <div className="mt-2 flex gap-2">
                <button onClick={() => { addToCart(user.id, it); toast.success("Moved to cart"); selectTab("cart"); }} className="rounded-full bg-gold px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-primary-foreground">
                  Add to Cart
                </button>
                <button onClick={() => removeFromWish(user.id, it.id)} className="rounded-full border border-border px-3 py-1 text-[10px] uppercase tracking-[0.2em] hover:border-destructive hover:text-destructive">
                  Remove
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Settings ---------- */
function MySettings() {
  const { user, refreshRole } = useAuth();
  const [profile, setProfile] = useState({ full_name: "", phone: "" });
  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");

  useEffect(() => {
    if (!user) return;
    setEmail(user.email || "");
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle().then(({ data }) => {
      if (data) setProfile({ full_name: data.full_name || "", phone: data.phone || "" });
    });
  }, [user]);

  const saveProfile = async () => {
    if (!user) return;
    if (profile.full_name && profile.full_name.length > 100) return toast.error("Name too long");
    if (profile.phone && profile.phone.length > 30) return toast.error("Phone too long");
    const { error } = await supabase.from("profiles").upsert({ id: user.id, ...profile, email: user.email });
    if (error) return toast.error(error.message);
    toast.success("Profile saved");
    refreshRole();
  };
  const saveEmail = async () => {
    if (!email || email.length > 255) return toast.error("Invalid email");
    const { error } = await supabase.auth.updateUser({ email });
    if (error) return toast.error(error.message);
    toast.success("Confirmation sent to your new email");
  };
  const savePwd = async () => {
    if (pwd.length < 8) return toast.error("Password must be 8+ characters");
    if (pwd.length > 72) return toast.error("Password too long");
    const { error } = await supabase.auth.updateUser({ password: pwd });
    if (error) return toast.error(error.message);
    toast.success("Password updated");
    setPwd("");
  };

  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl">Settings</h2>

      <Card title="Profile Info" icon={<UserIcon className="h-4 w-4 text-gold" />}>
        <Field label="Full Name" value={profile.full_name} onChange={(v) => setProfile({ ...profile, full_name: v })} />
        <Field label="Phone" value={profile.phone} onChange={(v) => setProfile({ ...profile, phone: v })} placeholder="+1 555 123 4567" />
        <SaveBtn onClick={saveProfile} />
      </Card>

      <Card title="Change Email" icon={<Mail className="h-4 w-4 text-gold" />}>
        <Field label="New Email" type="email" value={email} onChange={setEmail} />
        <SaveBtn onClick={saveEmail} label="Update Email" />
      </Card>

      <Card title="Change Password" icon={<Lock className="h-4 w-4 text-gold" />}>
        <Field label="New Password" type="password" value={pwd} onChange={setPwd} />
        <SaveBtn onClick={savePwd} label="Update Password" />
      </Card>
    </div>
  );
}

function Field({ label, value, onChange, type = "text", placeholder }: { label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string }) {
  return (
    <div>
      <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{label}</label>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2.5 focus:border-gold focus:outline-none" />
    </div>
  );
}
function Card({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="glass rounded-xl p-4 sm:p-5 space-y-3">
      <h3 className="font-display text-lg flex items-center gap-2">{icon} {title}</h3>
      {children}
    </div>
  );
}
function SaveBtn({ onClick, label = "Save" }: { onClick: () => void; label?: string }) {
  return (
    <button onClick={onClick} className="inline-flex items-center gap-2 rounded-full bg-gold px-5 py-2.5 text-xs uppercase tracking-widest text-primary-foreground">
      <Save className="h-4 w-4" /> {label}
    </button>
  );
}
