import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Shield, Truck, BadgeCheck, FileCheck } from "lucide-react";

export const Route = createFileRoute("/insurance")({
  head: () => ({
    meta: [
      { title: "Insurance Policy — Quality Jewelry Repair" },
      { name: "description", content: "Every package is fully insured up to $25,000 with UPS declared value coverage. Read our complete insurance policy." },
    ],
  }),
  component: InsurancePage,
});

export default function InsurancePage() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-20">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
        <p className="text-xs uppercase tracking-[0.3em] text-gold">Coverage</p>
        <h1 className="mt-4 font-display text-5xl md:text-7xl">Insurance Policy</h1>
        <p className="mt-6 text-lg text-muted-foreground">
          Your treasures are protected end-to-end. We partner with UPS Capital and Jewelers Mutual to insure every step of the journey.
        </p>
      </motion.div>

      <div className="mt-12 grid md:grid-cols-2 gap-6">
        {[
          { icon: Shield, t: "Up to $25,000 Coverage", d: "Standard insured shipping covers declared values up to $25,000. Higher coverage available on request." },
          { icon: Truck, t: "Two-Way Insured Shipping", d: "Both inbound and return shipments are fully insured and tracked via UPS." },
          { icon: BadgeCheck, t: "In-Atelier Coverage", d: "While in our care, your item is covered by our jewelers' block insurance policy." },
          { icon: FileCheck, t: "Claim Support", d: "In the rare event of loss or damage, our team handles every claim on your behalf." },
        ].map((c, i) => (
          <motion.div
            key={c.t}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: i * 0.08 }}
            className="glass rounded-2xl p-6 hover-lift"
          >
            <c.icon className="h-6 w-6 text-gold" />
            <h3 className="mt-4 font-display text-xl">{c.t}</h3>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{c.d}</p>
          </motion.div>
        ))}
      </div>

      <article className="mt-16 prose prose-invert max-w-none text-muted-foreground space-y-6">
        <h2 className="font-display text-3xl text-foreground">Full Policy Terms</h2>
        <p>
          All packages shipped through Quality Jewelry Repair are insured against loss, theft, and damage during transit. Coverage is provided through UPS Capital Insurance Agency, Inc., and underwritten by an authorized insurance carrier.
        </p>
        <p>
          Customers are required to declare an accurate replacement value at checkout. Any item exceeding $25,000 in declared value must be pre-approved and may require additional documentation.
        </p>
        <p>
          Claims for lost or damaged shipments must be initiated within 30 days of the shipment date. Our team will assist with documentation, valuation, and the entire claim resolution process.
        </p>
        <p>
          While in our possession, items are protected under our Jewelers Mutual jewelers' block policy, providing comprehensive coverage against fire, theft, and accidental damage.
        </p>
      </article>
    </div>
  );
}
