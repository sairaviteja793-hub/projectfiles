import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Shield, Lock, Database, Cookie, UserCheck, Mail, CreditCard, FileText, Sparkles } from "lucide-react";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Quality Jewelry Repair" },
      { name: "description", content: "How Quality Jewelry Repair collects, uses, and safeguards your personal information." },
    ],
  }),
  component: PrivacyPage,
});

const sections = [
  {
    icon: FileText,
    title: "Information We Collect",
    body: "We collect information you provide directly — name, email, shipping address, phone number, and payment details — when you create a repair order, contact our support team, or subscribe to updates.",
  },
  {
    icon: CreditCard,
    title: "Payment Security",
    body: "All payment processing is performed by PCI-DSS Level 1 compliant providers. Quality Jewelry Repair does not store full credit card numbers on our servers. Transactions are encrypted end-to-end with TLS 1.3.",
  },
  {
    icon: Sparkles,
    title: "How We Use Information",
    body: "We use your information solely to process repairs, ship items, communicate order status, and improve our services. We never sell or rent your personal data to third parties.",
  },
  {
    icon: Database,
    title: "Data Protection",
    body: "We employ industry-standard safeguards including encrypted databases, role-based access controls, regular penetration testing, and 24/7 fraud monitoring on every transaction.",
  },
  {
    icon: Cookie,
    title: "Cookies",
    body: "We use essential cookies for site functionality and analytics cookies (with your consent) to improve user experience. You may manage preferences in your browser at any time.",
  },
  {
    icon: UserCheck,
    title: "Your Rights",
    body: "You may request access, correction, or deletion of your personal data at any time by emailing privacy@qualityjewelryrepairs.com. We respond to all requests within 30 days.",
  },
];

const fadeUp: any = {
  hidden: { opacity: 0, y: 24 },
  visible: (i = 0) => ({ opacity: 1, y: 0, transition: { duration: 0.7, delay: i * 0.07, ease: [0.22, 1, 0.36, 1] } }),
};

function PrivacyPage() {
  return (
    <div className="overflow-x-clip">
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-border/60 bg-gradient-to-b from-accent/40 via-background to-background">
        <div className="absolute inset-0 -z-10 opacity-60">
          <div className="absolute -top-32 -right-32 h-96 w-96 rounded-full bg-gold/20 blur-3xl" />
          <div className="absolute -bottom-32 -left-32 h-96 w-96 rounded-full bg-gold/10 blur-3xl" />
        </div>

        <div className="mx-auto max-w-5xl px-6 py-24 text-center">
          <motion.div
            initial="hidden" animate="visible" variants={fadeUp}
            className="inline-flex items-center gap-2 rounded-full border border-gold/40 bg-card/60 px-4 py-1.5 text-xs uppercase tracking-[0.3em] text-gold"
          >
            <Shield className="h-3.5 w-3.5" /> Legal · Trust Center
          </motion.div>
          <motion.h1
            initial="hidden" animate="visible" variants={fadeUp} custom={1}
            className="mt-6 font-display text-5xl md:text-7xl leading-[1.05]"
          >
            Privacy <span className="gradient-gold-text italic">Policy</span>
          </motion.h1>
          <motion.p
            initial="hidden" animate="visible" variants={fadeUp} custom={2}
            className="mt-6 mx-auto max-w-2xl text-lg text-muted-foreground"
          >
            Your trust is the most valuable thing we hold. Here's exactly how we collect, use,
            and safeguard your information — written in plain English.
          </motion.p>
          <motion.p
            initial="hidden" animate="visible" variants={fadeUp} custom={3}
            className="mt-4 text-xs uppercase tracking-[0.3em] text-muted-foreground"
          >
            Last updated · May 2026
          </motion.p>
        </div>
      </section>

      {/* SECURITY HIGHLIGHTS */}
      <section className="mx-auto max-w-6xl px-6 -mt-12">
        <div className="grid md:grid-cols-3 gap-4">
          {[
            { icon: Lock, t: "256-bit SSL", d: "End-to-end TLS 1.3 encryption" },
            { icon: Shield, t: "PCI-DSS Level 1", d: "Payments never touch our servers" },
            { icon: Database, t: "Encrypted at rest", d: "Hardened, audited infrastructure" },
          ].map((b, i) => (
            <motion.div
              key={b.t}
              initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} custom={i}
              className="glass rounded-2xl p-6 hover-lift"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gold/15 border border-gold/30">
                <b.icon className="h-5 w-5 text-gold" />
              </div>
              <h3 className="mt-4 font-display text-xl">{b.t}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{b.d}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* SECTIONS */}
      <section className="mx-auto max-w-4xl px-6 py-24">
        <div className="space-y-6">
          {sections.map((s, i) => (
            <motion.article
              key={s.title}
              initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.2 }} variants={fadeUp} custom={i}
              className="group relative rounded-2xl border border-border bg-card p-8 hover-lift"
            >
              <div className="flex items-start gap-5">
                <div className="shrink-0 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-gold/20 to-gold/5 border border-gold/20 text-gold">
                  <s.icon className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-baseline gap-3">
                    <span className="font-display text-sm text-gold">{String(i + 1).padStart(2, "0")}</span>
                    <h2 className="font-display text-2xl md:text-3xl">{s.title}</h2>
                  </div>
                  <p className="mt-3 text-muted-foreground leading-relaxed">{s.body}</p>
                </div>
              </div>
            </motion.article>
          ))}
        </div>

        {/* CONTACT CARD */}
        <motion.div
          initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}
          className="mt-12 relative overflow-hidden rounded-3xl border border-gold/30 bg-gradient-to-br from-accent/40 via-card to-card p-10 text-center shadow-luxe"
        >
          <div className="absolute -top-20 -right-20 h-60 w-60 rounded-full bg-gold/20 blur-3xl" />
          <Mail className="mx-auto h-8 w-8 text-gold" />
          <h3 className="mt-4 font-display text-3xl">Questions about your privacy?</h3>
          <p className="mt-3 mx-auto max-w-md text-muted-foreground">
            Our team responds within one business day. We're here to help.
          </p>
          <a
            href="mailto:privacy@qualityjewelryrepairs.com"
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-gold px-8 py-3 text-sm font-medium uppercase tracking-[0.2em] text-primary-foreground shadow-gold transition-all duration-500 hover:scale-105"
          >
            privacy@qualityjewelryrepairs.com
          </a>
        </motion.div>
      </section>
    </div>
  );
}
