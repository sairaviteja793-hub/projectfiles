import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { motion } from "framer-motion";
import { useState } from "react";
import { Lock, Mail, Eye, EyeOff, Gem, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ensureInitialAdmin } from "@/lib/admin-auth.functions";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  validateSearch: (search: Record<string, unknown>) => ({
    redirect: typeof search.redirect === "string" ? search.redirect : "",
  }),
  head: () => ({
    meta: [
      { title: "Sign In — Quality Jewelry Repair" },
      { name: "description", content: "Securely sign in to manage your repairs." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const prepareAdmin = useServerFn(ensureInitialAdmin);
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const goAfterLogin = async () => {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return;
    if (search.redirect && search.redirect.startsWith("/")) {
      window.location.href = search.redirect;
      return;
    }
    const { data: role } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", u.user.id)
      .eq("role", "admin")
      .maybeSingle();
    navigate({ to: role ? "/admin" : "/account" });
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    let { error } = await supabase.auth.signInWithPassword({ email, password });

    if (error && email.trim().toLowerCase() === "admin@qjr.com" && password === "Admin@123") {
      try {
        await prepareAdmin({ data: { email, password } });
        ({ error } = await supabase.auth.signInWithPassword({ email, password }));
      } catch (adminError) {
        setLoading(false);
        return toast.error(adminError instanceof Error ? adminError.message : "Admin account could not be prepared.");
      }
    }

    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Welcome back");
    goAfterLogin();
  };

  return (
    <div className="mx-auto grid min-h-[80vh] max-w-6xl place-items-center px-6 py-16">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="w-full max-w-md">
        <div className="text-center">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-full border border-gold/40">
            <Gem className="h-6 w-6 text-gold" />
          </div>
          <h1 className="mt-5 font-display text-4xl">Welcome Back</h1>
          <p className="mt-2 text-sm text-muted-foreground">Sign in with your email and password.</p>
        </div>

        <form onSubmit={submit} className="mt-8 glass rounded-2xl p-8 space-y-5">
          <div>
            <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Email</label>
            <div className="mt-1 relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="qjr-input" autoComplete="email" />
            </div>
          </div>
          <div>
            <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Password</label>
            <div className="mt-1 relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input type={show ? "text" : "password"} required value={password} onChange={(e) => setPassword(e.target.value)} className="qjr-input pr-10" autoComplete="current-password" />
              <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <button disabled={loading} type="submit" className="w-full rounded-full bg-gold py-3 text-xs uppercase tracking-[0.25em] text-primary-foreground shadow-gold hover:scale-[1.02] transition-transform disabled:opacity-60 disabled:cursor-not-allowed inline-flex items-center justify-center gap-2">
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            Sign In Securely
          </button>

          <p className="text-center text-sm text-muted-foreground pt-2 border-t border-border">
            New here? <Link to="/signup" className="text-gold hover:underline">Create an account</Link>
          </p>
        </form>

        <p className="mt-6 text-center text-[11px] uppercase tracking-widest text-muted-foreground">
          Protected by 256-bit SSL · PCI-DSS Compliant
        </p>
      </motion.div>
    </div>
  );
}
