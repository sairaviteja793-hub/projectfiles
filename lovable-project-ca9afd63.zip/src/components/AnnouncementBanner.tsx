import { useEffect, useState } from "react";
import { X, Sparkles, Tag, Info } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Announcement {
  id: string;
  title: string;
  message: string;
  type: string;
}

export function AnnouncementBanner() {
  const [items, setItems] = useState<Announcement[]>([]);
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());

  useEffect(() => {
    supabase
      .from("announcements")
      .select("id,title,message,type")
      .eq("active", true)
      .or("expires_at.is.null,expires_at.gt." + new Date().toISOString())
      .order("created_at", { ascending: false })
      .limit(3)
      .then(({ data }) => setItems(data ?? []));

    const stored = typeof window !== "undefined" ? localStorage.getItem("dismissed_ann") : null;
    if (stored) setDismissed(new Set(JSON.parse(stored)));
  }, []);

  const dismiss = (id: string) => {
    const next = new Set(dismissed);
    next.add(id);
    setDismissed(next);
    localStorage.setItem("dismissed_ann", JSON.stringify([...next]));
  };

  const visible = items.filter((i) => !dismissed.has(i.id));
  if (visible.length === 0) return null;

  const a = visible[0];
  const Icon = a.type === "sale" ? Tag : a.type === "discount" ? Sparkles : Info;

  return (
    <div className="relative border-b border-red-700/40 bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-sm">
      <div className="mx-auto flex max-w-[88rem] items-center gap-3 px-4 py-2 text-sm">
        <Icon className="h-4 w-4 shrink-0" />
        <p className="flex-1 truncate">
          <span className="font-semibold">{a.title}</span>
          <span className="mx-2 opacity-70">·</span>
          <span className="opacity-95">{a.message}</span>
        </p>
        <button
          onClick={() => dismiss(a.id)}
          aria-label="Dismiss"
          className="rounded p-1 text-white/80 hover:bg-white/15 hover:text-white"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
