import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Plus, Trash2, UserPlus, Shield } from "lucide-react";
import { toast } from "sonner";
import { createStaff, listStaff, revokeStaff } from "@/lib/staff.functions";

interface StaffRow {
  id: string;
  email: string | null;
  full_name: string | null;
  created_at: string;
}

export function TeamTab() {
  const [staff, setStaff] = useState<StaffRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ full_name: "", email: "", password: "" });
  const [adding, setAdding] = useState(false);

  const list = useServerFn(listStaff);
  const create = useServerFn(createStaff);
  const revoke = useServerFn(revokeStaff);

  const load = async () => {
    setLoading(true);
    try {
      const { staff } = await list({ data: {} as any });
      setStaff(staff);
    } catch (e: any) {
      toast.error(e?.message ?? "Failed to load staff");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const add = async () => {
    if (!form.full_name.trim()) return toast.error("Name required");
    if (!form.email.trim()) return toast.error("Email required");
    if (form.password.length < 8) return toast.error("Password must be 8+ characters");
    setAdding(true);
    try {
      await create({ data: form });
      toast.success(`Staff account created for ${form.email}`);
      setForm({ full_name: "", email: "", password: "" });
      load();
    } catch (e: any) {
      toast.error(e?.message ?? "Failed to create staff");
    } finally {
      setAdding(false);
    }
  };

  const remove = async (s: StaffRow) => {
    if (!confirm(`Revoke access for ${s.email ?? s.full_name}? This deletes their account.`)) return;
    try {
      await revoke({ data: { user_id: s.id } });
      toast.success("Staff revoked");
      load();
    } catch (e: any) {
      toast.error(e?.message ?? "Failed to revoke");
    }
  };

  const genPassword = () => {
    const chars = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$";
    let pw = "";
    for (let i = 0; i < 12; i++) pw += chars[Math.floor(Math.random() * chars.length)];
    setForm({ ...form, password: pw });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-2xl flex items-center gap-2">
          <Shield className="h-5 w-5 text-gold" /> Team / Staff Accounts
        </h2>
        <p className="text-sm text-muted-foreground mt-1">
          Create login accounts for in-store workers. Staff can manage bookings, services, users, and announcements — but{" "}
          <span className="text-foreground font-medium">cannot see sales, analytics, payment settings, or this Team tab</span>.
        </p>
      </div>

      <div className="glass rounded-xl p-5 space-y-3">
        <h3 className="font-display text-lg flex items-center gap-2">
          <UserPlus className="h-4 w-4 text-gold" /> Create Staff Account
        </h3>
        <div className="grid sm:grid-cols-3 gap-3">
          <div>
            <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Full Name *</label>
            <input
              value={form.full_name}
              onChange={(e) => setForm({ ...form, full_name: e.target.value })}
              className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2.5"
            />
          </div>
          <div>
            <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Email *</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2.5"
            />
          </div>
          <div>
            <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground flex items-center justify-between">
              <span>Password *</span>
              <button type="button" onClick={genPassword} className="text-[10px] text-gold hover:underline">
                Generate
              </button>
            </label>
            <input
              type="text"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              placeholder="min 8 chars"
              className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2.5 font-mono text-sm"
            />
          </div>
        </div>
        <button
          onClick={add}
          disabled={adding}
          className="inline-flex items-center gap-2 rounded-full bg-gold px-5 py-2.5 text-xs uppercase tracking-widest text-primary-foreground disabled:opacity-60"
        >
          {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Create Account
        </button>
        <p className="text-xs text-muted-foreground">
          Share the email + password with the worker. They sign in at <span className="font-mono">/login</span> and land on the admin dashboard.
        </p>
      </div>

      <div className="glass rounded-xl p-5">
        <h3 className="font-display text-lg mb-3">Active Staff</h3>
        {loading ? (
          <div className="grid place-items-center py-10">
            <Loader2 className="h-5 w-5 animate-spin text-gold" />
          </div>
        ) : staff.length === 0 ? (
          <p className="text-sm text-muted-foreground py-4 text-center">No staff accounts yet.</p>
        ) : (
          <div className="divide-y divide-border">
            {staff.map((s) => (
              <div key={s.id} className="py-3 flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-emerald-500/15 text-emerald-600 grid place-items-center text-xs font-bold">
                  {(s.full_name || s.email || "?").slice(0, 1).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{s.full_name || "—"}</p>
                  <p className="text-xs text-muted-foreground truncate">{s.email || "—"}</p>
                </div>
                <p className="text-xs text-muted-foreground hidden sm:block">
                  Since {new Date(s.created_at).toLocaleDateString()}
                </p>
                <button
                  onClick={() => remove(s)}
                  className="p-2 rounded-lg text-destructive hover:bg-destructive/10"
                  title="Revoke access"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
