import { useEffect, useState } from "react";
import { X, Loader2, Mail, Phone, Calendar, DollarSign, Package, Heart } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Props {
  user: any;
  onClose: () => void;
}

export function UserHistoryDrawer({ user, onClose }: Props) {
  const [bookings, setBookings] = useState<any[]>([]);
  const [wishlist, setWishlist] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      const [{ data: bk }, { data: wl }] = await Promise.all([
        // Match by user_id (signed-in customers) OR customer_email (guest checkout)
        supabase
          .from("bookings")
          .select("*")
          .or(`user_id.eq.${user.id},customer_email.eq.${user.email ?? "__none__"}`)
          .order("created_at", { ascending: false }),
        (supabase.from("wishlists" as any).select("*").eq("user_id", user.id) as any),
      ]);
      if (cancelled) return;
      setBookings(bk ?? []);
      setWishlist(wl ?? []);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [user.id, user.email]);

  const totalSpend = bookings.reduce((s, b) => s + Number(b.total || 0), 0);
  const lastActivity = bookings[0]?.created_at ?? user.created_at;

  return (
    <div className="fixed inset-0 z-50 flex" onClick={onClose}>
      <div className="flex-1 bg-black/60 backdrop-blur-sm" />
      <aside
        onClick={(e) => e.stopPropagation()}
        className="w-full sm:w-[32rem] bg-card border-l border-border overflow-y-auto shadow-2xl"
      >
        <header className="sticky top-0 z-10 bg-card border-b border-border px-5 py-4 flex items-center justify-between">
          <div>
            <h2 className="font-display text-xl">{user.full_name || "Unnamed"}</h2>
            <p className="text-xs text-muted-foreground">Customer history</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-foreground/5">
            <X className="h-5 w-5" />
          </button>
        </header>

        <div className="p-5 space-y-5">
          {/* Contact */}
          <div className="glass rounded-xl p-4 space-y-2">
            {user.email && (
              <div className="flex items-center gap-2 text-sm">
                <Mail className="h-4 w-4 text-muted-foreground" /> {user.email}
              </div>
            )}
            {user.phone && (
              <div className="flex items-center gap-2 text-sm">
                <Phone className="h-4 w-4 text-muted-foreground" /> {user.phone}
              </div>
            )}
            <div className="flex items-center gap-2 text-sm">
              <Calendar className="h-4 w-4 text-muted-foreground" /> Joined{" "}
              {new Date(user.created_at).toLocaleDateString()}
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="glass rounded-xl p-4">
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Orders</p>
              <p className="font-display text-2xl mt-1">{bookings.length}</p>
            </div>
            <div className="glass rounded-xl p-4">
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Spend</p>
              <p className="font-display text-2xl mt-1 text-gold">${totalSpend.toFixed(0)}</p>
            </div>
            <div className="glass rounded-xl p-4">
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Wishlist</p>
              <p className="font-display text-2xl mt-1">{wishlist.length}</p>
            </div>
          </div>

          {lastActivity && (
            <p className="text-xs text-muted-foreground">
              Last activity: {new Date(lastActivity).toLocaleString()}
            </p>
          )}

          {/* Bookings */}
          <div>
            <h3 className="font-display text-lg flex items-center gap-2 mb-3">
              <Package className="h-4 w-4 text-gold" /> Order History
            </h3>
            {loading ? (
              <div className="grid place-items-center py-8">
                <Loader2 className="h-5 w-5 animate-spin text-gold" />
              </div>
            ) : bookings.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-6">No orders yet.</p>
            ) : (
              <div className="space-y-2">
                {bookings.map((b) => (
                  <div key={b.id} className="glass rounded-xl p-3">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="text-[10px] uppercase tracking-widest rounded-full bg-foreground/10 px-2 py-0.5">
                        {b.status}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(b.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm truncate">
                        {(b.items as any[])?.map((i: any) => i.title).join(", ") || "Order"}
                      </p>
                      <p className="font-display text-base shrink-0 flex items-center gap-1">
                        <DollarSign className="h-3 w-3 text-muted-foreground" />
                        {Number(b.total).toFixed(2)}
                      </p>
                    </div>
                    {b.notes && (
                      <p className="text-xs text-muted-foreground mt-1 italic">"{b.notes}"</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Wishlist */}
          {wishlist.length > 0 && (
            <div>
              <h3 className="font-display text-lg flex items-center gap-2 mb-3">
                <Heart className="h-4 w-4 text-rose-500" /> Wishlist ({wishlist.length})
              </h3>
              <div className="flex flex-wrap gap-2">
                {wishlist.map((w) => (
                  <span
                    key={w.id}
                    className="text-xs rounded-full border border-border px-3 py-1"
                  >
                    {w.service_title || w.service_id}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}
