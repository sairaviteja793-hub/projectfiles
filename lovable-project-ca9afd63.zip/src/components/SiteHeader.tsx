import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X, Gem, Shield, LogOut, ShoppingBag, Sparkles, Settings as SettingsIcon, Heart, ShoppingCart } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useAuth } from "@/hooks/useAuth";
import { cartCount, onCartChange } from "@/lib/cart-store";

const PUBLIC_NAV = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/how-it-works", label: "How It Works" },
  { to: "/insurance", label: "Insurance" },
  { to: "/contact", label: "Contact" },
] as const;

const USER_NAV = [
  { to: "/account", hash: "orders", label: "Orders", icon: ShoppingBag },
  { to: "/account", hash: "services", label: "Services", icon: Sparkles },
  { to: "/account", hash: "wishlist", label: "Wishlist", icon: Heart },
  { to: "/account", hash: "settings", label: "Settings", icon: SettingsIcon },
] as const;

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [count, setCount] = useState(0);
  const { location } = useRouterState();
  const { user, isAdmin, signOut } = useAuth();
  const showRepairCta = !["/login", "/signup"].includes(location.pathname);
  const repairHref = user ? "/repair" : "/login";
  const repairSearch = user ? undefined : ({ redirect: "/repair" } as const);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => { setOpen(false); }, [location.pathname, location.hash]);

  useEffect(() => {
    if (!user) { setCount(0); return; }
    setCount(cartCount(user.id));
    return onCartChange(() => setCount(cartCount(user.id)));
  }, [user?.id]);

  const CartIcon = (
    <Link to="/account" hash="cart" aria-label="Cart" className="relative inline-flex items-center justify-center h-10 w-10 rounded-full border border-border hover:border-gold hover:text-gold transition-colors">
      <ShoppingCart className="h-4 w-4" />
      {count > 0 && (
        <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-gold text-primary-foreground text-[10px] font-medium grid place-items-center">
          {count > 99 ? "99+" : count}
        </span>
      )}
    </Link>
  );

  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled ? "glass-strong border-b border-border/50 py-3" : "py-5"}`}>
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6">
        <Link to="/" className="flex items-center gap-2 group">
          <span className="relative flex h-10 w-10 items-center justify-center rounded-full border border-gold/40">
            <Gem className="h-5 w-5 text-gold transition-transform duration-700 group-hover:rotate-180" />
            <span className="absolute inset-0 rounded-full animate-glow opacity-50" />
          </span>
          <div className="flex flex-col leading-tight">
            <span className="font-display text-lg tracking-wide text-foreground">Quality</span>
            <span className="text-[10px] uppercase tracking-[0.3em] text-gold">Jewelry Repair</span>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-6">
          {user
            ? USER_NAV.map((n) => {
                const active = location.pathname === n.to && location.hash === n.hash;
                return (
                  <Link key={n.hash} to={n.to} hash={n.hash} className={`inline-flex items-center gap-1.5 text-sm uppercase tracking-[0.2em] transition-colors ${active ? "text-gold" : "text-foreground/70 hover:text-foreground"}`}>
                    <n.icon className="h-4 w-4" /> {n.label}
                  </Link>
                );
              })
            : PUBLIC_NAV.map((n) => {
                const active = location.pathname === n.to;
                return (
                  <Link key={n.to} to={n.to} className={`text-sm uppercase tracking-[0.2em] transition-colors ${active ? "text-gold" : "text-foreground/70 hover:text-foreground"}`}>
                    {n.label}
                  </Link>
                );
              })}
        </nav>

        <div className="hidden lg:flex items-center gap-3">
          <ThemeToggle />
          {user && CartIcon}
          {isAdmin && (
            <Link to="/admin" className="inline-flex items-center gap-1.5 text-sm uppercase tracking-[0.2em] text-gold hover:text-foreground transition-colors">
              <Shield className="h-4 w-4" /> Admin
            </Link>
          )}
          {user ? (
            <button onClick={signOut} className="inline-flex items-center gap-1.5 text-sm uppercase tracking-[0.2em] text-foreground/70 hover:text-gold transition-colors">
              <LogOut className="h-4 w-4" /> Sign Out
            </button>
          ) : (
            <Link to="/login" className="text-sm uppercase tracking-[0.2em] text-foreground/70 hover:text-gold transition-colors">
              Sign In
            </Link>
          )}
          {showRepairCta && (
            <Link to={repairHref} search={repairSearch as never} className="inline-flex items-center gap-2 rounded-full bg-gold px-6 py-2.5 text-sm font-medium uppercase tracking-wider text-primary-foreground shadow-gold transition-all duration-300 hover:scale-105 hover:shadow-luxe">
              Start Your Repair
            </Link>
          )}
        </div>

        <div className="lg:hidden flex items-center gap-2">
          {user && CartIcon}
          {showRepairCta && (
            <Link to={repairHref} search={repairSearch as never} className="inline-flex items-center justify-center rounded-full bg-gold px-3 py-2 text-[10px] font-medium uppercase tracking-wider text-primary-foreground shadow-gold">
              Repair
            </Link>
          )}
          <ThemeToggle />
          <button aria-label="Menu" onClick={() => setOpen((v) => !v)} className="rounded-full border border-border p-2 text-foreground">
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden glass-strong border-t border-border/50 mt-3">
          <nav className="flex flex-col px-6 py-6 gap-4">
            {user ? (
              <>
                {USER_NAV.map((n) => (
                  <Link key={n.hash} to={n.to} hash={n.hash} className="inline-flex items-center gap-2 text-sm uppercase tracking-[0.2em] text-foreground/80 hover:text-gold">
                    <n.icon className="h-4 w-4" /> {n.label}
                  </Link>
                ))}
                <Link to="/account" hash="cart" className="inline-flex items-center gap-2 text-sm uppercase tracking-[0.2em] text-foreground/80 hover:text-gold">
                  <ShoppingCart className="h-4 w-4" /> Cart {count > 0 && <span className="text-gold">({count})</span>}
                </Link>
                {isAdmin && (
                  <Link to="/admin" className="inline-flex items-center gap-2 text-sm uppercase tracking-[0.2em] text-gold">
                    <Shield className="h-4 w-4" /> Admin
                  </Link>
                )}
                <button onClick={signOut} className="text-left inline-flex items-center gap-2 text-sm uppercase tracking-[0.2em] text-foreground/80 hover:text-gold">
                  <LogOut className="h-4 w-4" /> Sign Out
                </button>
              </>
            ) : (
              <>
                {PUBLIC_NAV.map((n) => (
                  <Link key={n.to} to={n.to} className="text-sm uppercase tracking-[0.2em] text-foreground/80 hover:text-gold">
                    {n.label}
                  </Link>
                ))}
                <Link to="/login" className="text-sm uppercase tracking-[0.2em] text-foreground/80 hover:text-gold">Sign In</Link>
              </>
            )}
            {showRepairCta && (
              <Link to={repairHref} search={repairSearch as never} className="mt-2 inline-flex justify-center rounded-full bg-gold px-6 py-3 text-sm font-medium uppercase tracking-wider text-primary-foreground">
                Start Your Repair
              </Link>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
