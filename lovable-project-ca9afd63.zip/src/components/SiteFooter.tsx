import { Link } from "@tanstack/react-router";
import { Gem, Shield, Mail, Phone } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="relative mt-32 border-t border-border/60 bg-card/40">
      <div className="gold-divider" />
      <div className="mx-auto max-w-7xl px-6 py-16 grid gap-12 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2">
            <Gem className="h-5 w-5 text-gold" />
            <span className="font-display text-xl">Quality Jewelry Repair</span>
          </div>
          <p className="mt-4 max-w-sm text-sm text-muted-foreground leading-relaxed">
            America's trusted mail-in jewelry & watch repair atelier. Master craftsmanship,
            insured shipping, transparent pricing — trusted by 200,000+ customers.
          </p>
          <div className="mt-6 flex items-center gap-2 text-xs text-muted-foreground">
            <Shield className="h-4 w-4 text-gold" />
            <span>Fully insured · SSL secure checkout · PCI-compliant payments</span>
          </div>
        </div>

        <div>
          <h4 className="text-xs uppercase tracking-[0.25em] text-gold">Explore</h4>
          <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
            <li><Link to="/how-it-works" className="hover:text-foreground">How It Works</Link></li>
            <li><Link to="/insurance" className="hover:text-foreground">Insurance Policy</Link></li>
            <li><Link to="/privacy" className="hover:text-foreground">Privacy Policy</Link></li>
            <li><Link to="/contact" className="hover:text-foreground">Contact</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-xs uppercase tracking-[0.25em] text-gold">Contact</h4>
          <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
            <li className="flex items-center gap-2"><Mail className="h-4 w-4 text-gold" /><span>support@qualityjewelryrepairs.com</span></li>
            <li className="flex items-center gap-2"><Phone className="h-4 w-4 text-gold" /><span>Mon–Fri · 9am–6pm EST</span></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border/40 py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Quality Jewelry Repair. All rights reserved.
      </div>
    </footer>
  );
}
