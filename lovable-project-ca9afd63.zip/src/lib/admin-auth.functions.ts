import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const ensureInitialAdmin = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z.object({ email: z.string().email(), password: z.string().min(1) }).parse(input),
  )
  .handler(async ({ data }) => {
    const email = data.email.trim().toLowerCase();

    if (email !== "admin@qjr.com" || data.password !== "Admin@123") {
      throw new Response("Invalid admin credentials", { status: 401 });
    }

    const { count, error: countError } = await supabaseAdmin
      .from("user_roles")
      .select("id", { count: "exact", head: true })
      .eq("role", "admin");

    if (countError) throw new Error(countError.message);
    if ((count ?? 0) > 0) return { ready: true };

    const { data: listed, error: listError } = await supabaseAdmin.auth.admin.listUsers({
      page: 1,
      perPage: 1000,
    });
    if (listError) throw new Error(listError.message);

    let adminUser = listed.users.find((u) => u.email?.toLowerCase() === email) ?? null;

    if (!adminUser) {
      const { data: created, error: createError } = await supabaseAdmin.auth.admin.createUser({
        email,
        password: data.password,
        email_confirm: true,
        user_metadata: { full_name: "Admin" },
      });
      if (createError) throw new Error(createError.message);
      adminUser = created.user;
    } else {
      const { data: updated, error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
        adminUser.id,
        { password: data.password, email_confirm: true, user_metadata: { ...adminUser.user_metadata, full_name: adminUser.user_metadata?.full_name ?? "Admin" } } as any,
      );
      if (updateError) throw new Error(updateError.message);
      adminUser = updated.user;
    }

    if (!adminUser) throw new Error("Unable to prepare admin account.");

    const now = new Date().toISOString();
    const { error: profileError } = await supabaseAdmin.from("profiles").upsert({
      id: adminUser.id,
      email,
      full_name: adminUser.user_metadata?.full_name ?? "Admin",
      updated_at: now,
    });
    if (profileError) throw new Error(profileError.message);

    const { error: roleError } = await supabaseAdmin
      .from("user_roles")
      .upsert({ user_id: adminUser.id, role: "admin" }, { onConflict: "user_id,role" });
    if (roleError) throw new Error(roleError.message);

    return { ready: true };
  });