// Shared service catalog (extracted from /repair) so both routes use the same data.
import imgRings from "@/assets/svc-rings.jpg";
import imgEarrings from "@/assets/svc-earrings.jpg";
import imgChain from "@/assets/svc-chain.jpg";
import imgEngraving from "@/assets/svc-engraving.jpg";
import imgStones from "@/assets/svc-stones.jpg";
import imgBracelet from "@/assets/svc-bracelet.jpg";
import imgPendant from "@/assets/svc-pendant.jpg";
import imgPolishing from "@/assets/svc-polishing.jpg";
import imgWatch from "@/assets/svc-watch.jpg";
import { Gem, Watch, Wrench, Sparkles, Star, Award, Hammer, Palette, FileText, Settings as SettingsIcon } from "lucide-react";

export type CategoryId =
  | "all" | "popular" | "soldering" | "ring-repair" | "cleaning"
  | "ring-sizing" | "stone" | "engraving" | "appraisal"
  | "something-else" | "replacement";

export type Service = {
  id: string;
  name: string;
  price: number;
  desc: string;
  category: CategoryId;
  popular?: boolean;
  image: string;
};

export const CATEGORIES: { id: CategoryId; label: string; icon: typeof Gem }[] = [
  { id: "all", label: "All Services", icon: Sparkles },
  { id: "popular", label: "Popular", icon: Star },
  { id: "soldering", label: "Soldering Work", icon: Hammer },
  { id: "ring-repair", label: "Ring Repair", icon: Gem },
  { id: "cleaning", label: "Cleaning & Restoration", icon: Palette },
  { id: "ring-sizing", label: "Ring Sizing", icon: Gem },
  { id: "stone", label: "Stone & Setting", icon: Sparkles },
  { id: "engraving", label: "Engraving", icon: FileText },
  { id: "appraisal", label: "Appraisal", icon: Award },
  { id: "something-else", label: "Something Else", icon: Wrench },
  { id: "replacement", label: "Replacement Parts", icon: SettingsIcon },
];

export const CATEGORY_IMAGE: Record<string, string> = {
  soldering: imgEarrings,
  "ring-repair": imgRings,
  cleaning: imgPolishing,
  "ring-sizing": imgRings,
  stone: imgStones,
  engraving: imgEngraving,
  appraisal: imgPendant,
  "something-else": imgPendant,
  replacement: imgWatch,
};

export const SERVICES: Service[] = [
  { id: "earring-post-soldering", name: "Earring Post Soldering", price: 69, desc: "Repair detached or broken earring posts with precision soldering.", category: "soldering", popular: true, image: imgEarrings },
  { id: "earring-post-back", name: "Earring Post Back", price: 30, desc: "Repair or replace missing, damaged or worn earring posts.", category: "soldering", popular: true, image: imgEarrings },
  { id: "shorten-chain", name: "Shorten / Resize Chain", price: 29, desc: "Take out links for the perfect fit.", category: "soldering", popular: true, image: imgChain },
  { id: "clasp-repair", name: "Clasp Repair / Replacement", price: 48, desc: "Get your broken clasp or lock fixed or replaced.", category: "soldering", popular: true, image: imgChain },
  { id: "chain-soldering", name: "Chain Repair / Soldering", price: 25, desc: "Soldering work and chain repair by master jewelers.", category: "soldering", image: imgChain },
  { id: "earring-back-soldering", name: "Earring Back Soldering", price: 30, desc: "Secure earring backs with professional soldering.", category: "soldering", image: imgEarrings },
  { id: "earring-back-conversion", name: "Earring Back Conversion", price: 40, desc: "Convert earring backs to your preferred style.", category: "soldering", image: imgEarrings },
  { id: "retip-prongs", name: "Re-tip Prongs", price: 29, desc: "Restore worn prong tips to keep stones secure.", category: "ring-repair", image: imgRings },
  { id: "ring-shank-repair", name: "Ring Shank Repair", price: 45, desc: "Restore the shape of your ring with full or half shank replacement.", category: "ring-repair", image: imgRings },
  { id: "rebuild-prongs", name: "Rebuild 1–4 Prongs", price: 29, desc: "Smoothen the setting by rebuilding the prongs of your jewelry.", category: "ring-repair", image: imgRings },
  { id: "ring-reshaping", name: "Ring Reshaping", price: 53, desc: "Bring a bent or distorted ring back to perfect circular form.", category: "ring-repair", image: imgRings },
  { id: "jewelry-polishing", name: "Jewelry Polishing", price: 30, desc: "Clean your jewelry with our polishing buff service.", category: "cleaning", image: imgPolishing },
  { id: "remove-watch-links", name: "Remove Watch Links", price: 5, desc: "Professional watch link removal for the perfect fit.", category: "cleaning", popular: true, image: imgWatch },
  { id: "watch-battery", name: "Watch Battery Replacement", price: 20, desc: "Replace a dead battery on any kind of watch.", category: "cleaning", image: imgWatch },
  { id: "band-case-refinish", name: "Band & Case Refinishing", price: 45, desc: "Restore the original luster of your watch case and band.", category: "cleaning", image: imgWatch },
  { id: "quartz-overhaul", name: "Clean & Overhaul: Quartz Movement", price: 195, desc: "Complete quartz movement service.", category: "cleaning", image: imgWatch },
  { id: "mechanical-overhaul", name: "Mechanical Movement", price: 195, desc: "Overhaul your mechanical (wind-up) watch.", category: "cleaning", image: imgWatch },
  { id: "untangle", name: "Untangle Item(s)", price: 10, desc: "Professional chain untanglers at your service.", category: "cleaning", image: imgChain },
  { id: "rhodium-plating", name: "Rhodium Plating", price: 69, desc: "Restore the bright white finish of white gold.", category: "cleaning", image: imgRings },
  { id: "gold-plating", name: "Gold Plating (Electroplating)", price: 60, desc: "Professional gold plating service for your jewelry.", category: "cleaning", image: imgRings },
  { id: "spa-service", name: "Jewelry Spa Service", price: 44, desc: "Steam cleaning, stone tightening and polishing maintenance.", category: "cleaning", image: imgPolishing },
  { id: "enamel-repair", name: "Jewelry Enamel Repair", price: 33.5, desc: "Add bold colors with applied colored glass powder.", category: "cleaning", image: imgPolishing },
  { id: "gemstone-polishing", name: "Gemstone Polishing", price: 65, desc: "Restore brilliance to dull or scratched gemstones.", category: "cleaning", image: imgStones },
  { id: "pearl-restringing", name: "Pearl Restringing", price: 15, desc: "Restring pearls, beaded necklaces, bracelets or anklets.", category: "cleaning", image: imgPendant },
  { id: "ring-resize-down", name: "Ring Resizing Down", price: 40, desc: "Make your ring smaller for the perfect fit.", category: "ring-sizing", image: imgRings },
  { id: "ring-resize-up", name: "Ring Resizing Up", price: 40, desc: "Enlarge your ring to make it a perfect fit.", category: "ring-sizing", image: imgRings },
  { id: "gemstone-replacement", name: "Gemstone Replacement", price: 5, desc: "Replace lost or damaged gemstones.", category: "stone", image: imgStones },
  { id: "stone-tightening", name: "Stone Tightening", price: 50, desc: "Secure loose stones so none go missing.", category: "stone", image: imgStones },
  { id: "gemstone-setting", name: "Gemstone Setting", price: 5, desc: "Professional lapidary setting service.", category: "stone", image: imgStones },
  { id: "diamond-setting", name: "Diamond Setting", price: 5, desc: "Replace a missing diamond and set it properly.", category: "stone", image: imgStones },
  { id: "ring-engraving", name: "Ring Engraving", price: 40, desc: "Personalize any ring with our engraving service.", category: "engraving", image: imgEngraving },
  { id: "bracelet-engraving", name: "Bracelet / Anklet Engraving", price: 35, desc: "Personalize with a custom message.", category: "engraving", image: imgBracelet },
  { id: "watch-engraving", name: "Watch & Unique Item Engraving", price: 40, desc: "Engrave any personalized message on your watch.", category: "engraving", image: imgWatch },
  { id: "jewelry-appraisal", name: "Jewelry Appraisal Document", price: 105, desc: "Certified appraisal for insurance and valuation.", category: "appraisal", image: imgPendant },
  { id: "metal-testing", name: "Metal Testing", price: 15, desc: "Verify the precious metal content of your piece.", category: "appraisal", image: imgRings },
  { id: "watch-appraisal", name: "Watch Appraisal Document", price: 115, desc: "Get the full value of your watch with a certified appraisal.", category: "appraisal", image: imgWatch },
  { id: "pressure-test", name: "Pressure Test", price: 175, desc: "Verify water resistance of your timepiece.", category: "appraisal", image: imgWatch },
  { id: "loose-gem-appraisal", name: "Loose Gemstone Appraisal", price: 105, desc: "Stones appraised by certified gemologists.", category: "appraisal", image: imgStones },
  { id: "custom-estimate", name: "Custom Made Jewelry Estimate", price: 10, desc: "Estimate for a one-of-a-kind custom piece.", category: "something-else", image: imgPendant },
  { id: "cad-render", name: "3D Design Rendering (CAD File)", price: 150, desc: "Photorealistic CAD render of your design.", category: "something-else", image: imgEngraving },
  { id: "hinge-repair", name: "Hinge Repair", price: 45, desc: "Restore the function of broken hinges.", category: "replacement", image: imgBracelet },
  { id: "stem-crown", name: "Stem & Crown Replacement", price: 75, desc: "Replace damaged watch stem or crown.", category: "replacement", image: imgWatch },
  { id: "watch-band", name: "Repair / Replace Watch Band", price: 45, desc: "Replace your worn or broken watch band.", category: "replacement", image: imgWatch },
  { id: "watch-crystal", name: "Watch Crystal Replacement", price: 75, desc: "Replace a damaged watch crystal with a new glass.", category: "replacement", image: imgWatch },
  { id: "jump-ring", name: "Repair / Replace Jump Ring", price: 19, desc: "Restore broken jump rings on chains and pendants.", category: "replacement", image: imgChain },
  { id: "bail-repair", name: "Bail Repair & Replacement", price: 39, desc: "Fix or replace pendant bails.", category: "replacement", image: imgPendant },
];
