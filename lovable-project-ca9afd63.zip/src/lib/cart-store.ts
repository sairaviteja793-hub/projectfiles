// Shared client-side stores for cart and wishlist.
// - Cart: localStorage, keyed by user id (fast, device-local).
// - Wishlist: Supabase (cross-device) with a localStorage cache for instant UI.
// Window events keep header badges and other components in sync.

import { supabase } from "@/integrations/supabase/client";

export type CartItem = {
  id: string;
  title: string;
  category: string;
  price: number;
  image?: string;
  qty: number;
};

export type WishItem = Omit<CartItem, "qty">;

const CART_EVT = "qjr-cart-changed";
const WISH_EVT = "qjr-wish-changed";

const cartKey = (uid?: string | null) => (uid ? `qjr.cart.${uid}` : `qjr.cart.guest`);
const wishKey = (uid?: string | null) => (uid ? `qjr.wish.${uid}` : `qjr.wish.guest`);

const read = <T,>(key: string): T[] => {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T[]) : [];
  } catch {
    return [];
  }
};
const write = (key: string, val: unknown, evt: string) => {
  if (typeof window === "undefined") return;
  localStorage.setItem(key, JSON.stringify(val));
  window.dispatchEvent(new CustomEvent(evt));
};

/* ---------- Cart (local-only) ---------- */
export const readCart = (uid?: string | null) => read<CartItem>(cartKey(uid));
export const writeCart = (uid: string | null | undefined, items: CartItem[]) =>
  write(cartKey(uid), items, CART_EVT);

export function addToCart(uid: string | null | undefined, item: WishItem, qty = 1) {
  const items = readCart(uid);
  const i = items.findIndex((x) => x.id === item.id);
  if (i >= 0) items[i].qty += qty;
  else items.push({ ...item, qty });
  writeCart(uid, items);
}
export function updateCartQty(uid: string | null | undefined, id: string, qty: number) {
  const items = readCart(uid);
  const i = items.findIndex((x) => x.id === id);
  if (i < 0) return;
  if (qty <= 0) items.splice(i, 1);
  else items[i].qty = qty;
  writeCart(uid, items);
}
export const removeFromCart = (uid: string | null | undefined, id: string) =>
  writeCart(uid, readCart(uid).filter((x) => x.id !== id));
export const clearCart = (uid: string | null | undefined) => writeCart(uid, []);
export const cartCount = (uid: string | null | undefined) =>
  readCart(uid).reduce((n, i) => n + i.qty, 0);

/* ---------- Wishlist (DB-backed with local cache) ---------- */
export const readWish = (uid?: string | null) => read<WishItem>(wishKey(uid));
const setWishCache = (uid: string | null | undefined, items: WishItem[]) =>
  write(wishKey(uid), items, WISH_EVT);

// Pull authoritative wishlist from DB, update local cache.
export async function syncWishFromDb(uid: string | null | undefined) {
  if (!uid) return [];
  const { data, error } = await supabase
    .from("wishlists" as any)
    .select("item_id,title,category,price,image,created_at")
    .order("created_at", { ascending: false });
  if (error) {
    // Fall back to cache silently (e.g. migration not yet applied)
    return readWish(uid);
  }
  const items: WishItem[] = (data ?? []).map((r: any) => ({
    id: r.item_id,
    title: r.title,
    category: r.category,
    price: Number(r.price),
    image: r.image ?? undefined,
  }));
  setWishCache(uid, items);
  return items;
}

export async function toggleWish(uid: string | null | undefined, item: WishItem): Promise<boolean> {
  if (!uid) return false;
  const items = readWish(uid);
  const i = items.findIndex((x) => x.id === item.id);
  if (i >= 0) {
    items.splice(i, 1);
    setWishCache(uid, items);
    await supabase.from("wishlists" as any).delete().eq("user_id", uid).eq("item_id", item.id);
    return false;
  }
  items.unshift(item);
  setWishCache(uid, items);
  await supabase.from("wishlists" as any).upsert(
    {
      user_id: uid,
      item_id: item.id,
      title: item.title,
      category: item.category,
      price: item.price,
      image: item.image ?? null,
    },
    { onConflict: "user_id,item_id" }
  );
  return true;
}

export async function removeFromWish(uid: string | null | undefined, id: string) {
  if (!uid) return;
  setWishCache(uid, readWish(uid).filter((x) => x.id !== id));
  await supabase.from("wishlists" as any).delete().eq("user_id", uid).eq("item_id", id);
}

export const isInWish = (uid: string | null | undefined, id: string) =>
  readWish(uid).some((x) => x.id === id);

/* ---------- Subscriptions ---------- */
export function onCartChange(cb: () => void) {
  if (typeof window === "undefined") return () => {};
  const h = () => cb();
  window.addEventListener(CART_EVT, h);
  window.addEventListener("storage", h);
  return () => {
    window.removeEventListener(CART_EVT, h);
    window.removeEventListener("storage", h);
  };
}
export function onWishChange(cb: () => void) {
  if (typeof window === "undefined") return () => {};
  const h = () => cb();
  window.addEventListener(WISH_EVT, h);
  window.addEventListener("storage", h);
  return () => {
    window.removeEventListener(WISH_EVT, h);
    window.removeEventListener("storage", h);
  };
}
