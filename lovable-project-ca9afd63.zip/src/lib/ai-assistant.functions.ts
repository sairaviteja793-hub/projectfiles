import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const MessageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string().min(1).max(2000),
});

export const askAssistant = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z
      .object({
        messages: z.array(MessageSchema).min(1).max(20),
        context: z.enum(["public", "user", "admin"]).default("public"),
      })
      .parse(d),
  )
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("LOVABLE_API_KEY is not configured");

    // Load live catalog so the assistant can quote real services + prices.
    const { data: services } = await supabaseAdmin
      .from("services")
      .select("title, category, price, description")
      .eq("active", true)
      .order("category")
      .limit(60);

    const catalog =
      (services ?? [])
        .map(
          (s: any) =>
            `- ${s.title} (${s.category}) — $${Number(s.price).toFixed(2)}${
              s.description ? `: ${s.description}` : ""
            }`,
        )
        .join("\n") || "Catalog is currently empty.";

    const systemPrompt = `You are "Sparkle", the friendly AI concierge for Quality Jewelry Repair — a premium mail-in jewelry & watch repair atelier.

GROUND TRUTH — current service catalog:
${catalog}

POLICIES:
- Free insured shipping label provided after checkout.
- All work backed by a lifetime craftsmanship guarantee.
- Typical turnaround: 7–14 business days from receipt.
- Payment accepted online (card) or in-store. Pay on delivery available.
- Returns: damaged-in-transit claims covered by insurance.

YOUR JOB:
- Answer questions about prices, services, turnaround, policies.
- Suggest the right service based on what the customer describes.
- Be concise (3–6 sentences typical), warm, and specific (quote real prices).
- If asked about something outside jewelry/watch repair, gently redirect.
- ${
      data.context === "admin"
        ? "You're talking to a STAFF member — you may also help with operational questions (order lookups, status meanings, policy reminders)."
        : data.context === "user"
          ? "You're talking to a SIGNED-IN customer — feel free to suggest services they might like."
          : "You're talking to a website visitor — encourage them to start a repair when relevant."
    }
- Never invent prices or services not in the catalog above. If unsure, say so and offer to connect them with a human.`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [{ role: "system", content: systemPrompt }, ...data.messages],
      }),
    });

    if (res.status === 429) throw new Error("Too many requests right now — please try again in a moment.");
    if (res.status === 402) throw new Error("AI credits exhausted. Please add credits in Workspace settings.");
    if (!res.ok) {
      const t = await res.text();
      console.error("AI gateway error", res.status, t);
      throw new Error("AI service is unavailable. Please try again shortly.");
    }

    const json = (await res.json()) as any;
    const reply =
      json?.choices?.[0]?.message?.content ??
      "Sorry, I couldn't generate a response. Please try rephrasing your question.";
    return { reply };
  });
