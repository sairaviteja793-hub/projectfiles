# Implementation Plan

You asked for a lot — I'll group it by priority (AI + subaccounts first, as you noted).

## 1. AI Assistant (Lovable AI) — Priority
A floating chat widget powered by Lovable AI (Gemini) available on:
- **Home page & all public pages** — answers about services, prices, policies, suggests repairs
- **User account** — order status help, personalized service suggestions
- **Admin page** — operational Q&A (e.g. "how many pending orders this week", policy lookup)

Built via a `createServerFn` calling the Lovable AI Gateway with streaming. The system prompt is loaded with your services catalog + policies so answers stay grounded. No client-side API key.

## 2. Staff Subaccounts — Priority
- New role `staff` added to `app_role` enum
- Admin gets a **"Team"** tab to create staff accounts (email + temp password) and revoke them
- Staff login lands on the admin dashboard but the **Sales / Revenue tab is hidden** (gated on `isAdmin`, not `isStaff`)
- Staff can: view/manage bookings, services, customers, inventory
- Staff cannot: see revenue, create other staff, change settings, view Stripe data
- Enforced both in UI and via RLS (`has_role(uid, 'admin' OR 'staff')` for shared tables, `has_role(uid, 'admin')` only for sales views)

## 3. User Order History (Admin view)
Click a user in the admin Users tab → side drawer showing their full bookings history, total spend, wishlist, and last activity.

## 4. Recommendation System
- Track lightweight `user_events` (viewed_service, added_to_cart, booked) in a new table
- Personalized "Recommended for you" section on `/services` and account dashboard
- Algorithm: category affinity from past bookings + items frequently bought together + fallback to popular

## 5. Auto Reminders / Notifications
- DB trigger on `bookings.status` change inserts a row into `notifications` table
- In-app bell icon in header with unread count + dropdown
- (Email reminders deferred — needs domain setup; ask if you want it)

## 6. Announcement Banner Restyle
- Move banner **below** the header (currently overlapping/inside)
- Change color from green → **red** (using `--destructive` token) with white text

## 7. Mobile Responsiveness Pass
Audit and fix on all pages: home, services, repair, account, admin, login. Issues to fix: header nav collapse, hero padding, card grids stacking, admin sidebar → drawer on mobile, table horizontal scroll.

## Technical Section
- **DB migration**: add `staff` to `app_role` enum; tables `user_events`, `notifications`; trigger `bookings_status_change_notify`; RLS policies for staff role; admin can SELECT all bookings per-user.
- **Files added**: `src/lib/ai-assistant.functions.ts`, `src/components/AiChatWidget.tsx`, `src/components/admin/TeamTab.tsx`, `src/components/admin/UserHistoryDrawer.tsx`, `src/components/NotificationBell.tsx`, `src/lib/recommendations.ts`.
- **Files edited**: `useAuth.tsx` (add `isStaff`), `admin.tsx` (gate Sales tab, add Team tab, user drawer), `AnnouncementBanner.tsx` (red, below header), `__root.tsx` (mount widget + banner), `services.tsx` + `account.tsx` (recommendations), every route (mobile pass).
- **Secrets**: uses existing `LOVABLE_API_KEY` (auto-provisioned, free tier).

## Scope Confirmation
This is ~2 hours of work. I'll ship **AI assistant + subaccounts + user history + announcement fix** in this round (your priorities). Recommendations, reminders, and the full mobile pass will follow in the next round so each piece is reviewable. Sound good?
